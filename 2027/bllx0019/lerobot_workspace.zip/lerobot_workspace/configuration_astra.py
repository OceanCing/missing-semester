"""
Configuration class for Orbbec Astra Pro depth camera.

The Astra Pro only supports the OpenNI2 protocol (no newer Orbbec SDK).
Depth is read via OpenNI2 C API (ctypes), colour via OpenCV UVC.

Required dependencies:
    pip install numpy opencv-python
    + Orbbec OpenNI2 SDK system-wide (https://developer.orbbec.com.cn)
      On Windows: the SDK installer puts OpenNI2.dll in
      C:\\Program Files\\OpenNI2\\Redist\\

No other pip packages are needed — the _openni2_ctypes module wraps the
OpenNI2 C API directly via ctypes, avoiding the Python-2-only `openni`
package on PyPI.
"""

from dataclasses import dataclass
from typing import Optional
from lerobot.cameras.configs import ColorMode, Cv2Rotation


@dataclass
class OrbbecAstraCameraConfig:
    """Configuration for Orbbec Astra Pro depth camera.

    Attributes:
        color_index: OpenCV device index for colour stream.
            On Windows the Astra Pro colour stream is typically index 0.
        fps: Target frame rate (default 30).
        width: Colour image width in pixels.
        height: Colour image height in pixels.
        depth_width: Depth map width (Astra Pro fixed: 640).
        depth_height: Depth map height (Astra Pro fixed: 480).
        color_mode: Output colour format (RGB or BGR).
        rotation: Optional rotation applied after capture.
        use_depth: Enable depth stream.
        warmup_frames: Frames to discard on connect() for auto-exposure.
        focus_range: (min_mm, max_mm) — depth values outside this range
            are clamped to 0.
        openni2_lib_path: Optional path to OpenNI2.dll / libOpenNI2.so.
            If not set, _openni2_ctypes will search standard locations.
    """

    # --- Core settings ---
    color_index: int = 0
    fps: int = 30
    width: int = 640
    height: int = 480
    color_mode: ColorMode = ColorMode.RGB
    rotation: Cv2Rotation = Cv2Rotation.NO_ROTATION

    # --- Depth settings ---
    use_depth: bool = True
    depth_width: int = 640
    depth_height: int = 480
    focus_range: tuple = (200, 5000)

    # --- Runtime ---
    warmup_frames: int = 5
    openni2_lib_path: Optional[str] = None

    # --- Misc ---
    mock: bool = False
