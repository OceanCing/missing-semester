"""
Low-level debug script — directly exercises the OpenNI2 C API step by step
and prints extended error messages for every failure.

Uses the SDK's own OpenNI2.dll that DepthReaderPoll.exe successfully uses.
"""

import ctypes
import os
import sys

# ------------ load the DLL that works (same as DepthReaderPoll.exe) ----------
DLL = (
    r"E:\ClaudeWorkspace\OpenNI_2.3.0.86_202210111950_"
    r"4c8f5aa4_beta6_windows\samples\bin\OpenNI2.dll"
)
if not os.path.isfile(DLL):
    # Fall back to installed location
    DLL = r"C:\Program Files\OpenNI2\Redist\OpenNI2.dll"

print(f"DLL: {DLL}")
lib = ctypes.cdll.LoadLibrary(DLL)

# ------------ types ------------
ONI_SENSOR_DEPTH  = 3
ONI_SENSOR_COLOR  = 2
ONI_API_VERSION   = 2003
ONI_STATUS_OK     = 0

# ------------ signatures ------------
lib.oniInitialize.argtypes = [ctypes.c_int]
lib.oniInitialize.restype  = ctypes.c_int

lib.oniShutdown.argtypes = []
lib.oniShutdown.restype  = None

lib.oniGetExtendedError.argtypes = []
lib.oniGetExtendedError.restype  = ctypes.c_char_p

lib.oniDeviceOpen.argtypes = [ctypes.c_char_p, ctypes.POINTER(ctypes.c_void_p)]
lib.oniDeviceOpen.restype  = ctypes.c_int

lib.oniDeviceCreateStream.argtypes = [
    ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_void_p)
]
lib.oniDeviceCreateStream.restype = ctypes.c_int

lib.oniStreamStart.argtypes = [ctypes.c_void_p]
lib.oniStreamStart.restype  = ctypes.c_int

lib.oniStreamStop.argtypes = [ctypes.c_void_p]
lib.oniStreamStop.restype  = None

lib.oniDeviceClose.argtypes = [ctypes.c_void_p]
lib.oniDeviceClose.restype  = ctypes.c_int

def err():
    """Get extended error string."""
    try:
        return lib.oniGetExtendedError().decode("utf-8", errors="replace")
    except Exception:
        return "<could not get error>"

# ------------ step-by-step ------------
print("\n=== Step 1: oniInitialize ===")
s = lib.oniInitialize(ONI_API_VERSION)
print(f"  status={s} {'OK' if s == ONI_STATUS_OK else 'FAIL: '+err()}")

print("\n=== Step 2: oniDeviceOpen(NULL) ===")
dev = ctypes.c_void_p()
s = lib.oniDeviceOpen(None, ctypes.byref(dev))
print(f"  status={s} dev={dev.value:#x} {'OK' if s == ONI_STATUS_OK else 'FAIL: '+err()}")

# Get device info
print("\n=== Step 3: oniDeviceGetInfo ===")
class OniDeviceInfo(ctypes.Structure):
    _fields_ = [
        ("uri", ctypes.c_char * 256),
        ("vendor", ctypes.c_char * 256),
        ("name", ctypes.c_char * 256),
        ("serialNumber", ctypes.c_char * 256),
        ("usbVendorId", ctypes.c_uint16),
        ("usbProductId", ctypes.c_uint16),
    ]
lib.oniDeviceGetInfo.argtypes = [ctypes.c_void_p, ctypes.POINTER(OniDeviceInfo)]
lib.oniDeviceGetInfo.restype = ctypes.c_int

info = OniDeviceInfo()
s = lib.oniDeviceGetInfo(dev, ctypes.byref(info))
if s == ONI_STATUS_OK:
    print(f"  name={info.name.decode('utf-8')}, vendor={info.vendor.decode('utf-8')}")
else:
    print(f"  status={s} FAIL: {err()}")

# Check sensor info
print("\n=== Step 4: oniDeviceGetSensorInfo(DEPTH) ===")
class OniVideoMode(ctypes.Structure):
    _fields_ = [
        ("pixelFormat", ctypes.c_int),
        ("resolutionX", ctypes.c_int),
        ("resolutionY", ctypes.c_int),
        ("fps", ctypes.c_int),
    ]
class OniSensorInfo(ctypes.Structure):
    _fields_ = [
        ("sensorType", ctypes.c_int),
        ("numSupportedVideoModes", ctypes.c_int),
        ("pSupportedVideoModes", ctypes.POINTER(OniVideoMode)),
    ]

lib.oniDeviceGetSensorInfo.argtypes = [ctypes.c_void_p, ctypes.c_int]
lib.oniDeviceGetSensorInfo.restype = ctypes.POINTER(OniSensorInfo)

si_depth = lib.oniDeviceGetSensorInfo(dev, ONI_SENSOR_DEPTH)
if si_depth:
    si = si_depth.contents
    print(f"  sensorType={si.sensorType} modes={si.numSupportedVideoModes}")
    if si.numSupportedVideoModes > 0 and si.pSupportedVideoModes:
        for i in range(min(si.numSupportedVideoModes, 5)):
            vm = si.pSupportedVideoModes[i]
            print(f"    [{i}] {vm.resolutionX}x{vm.resolutionY}@{vm.fps}fps fmt={vm.pixelFormat}")
else:
    print("  NULL — no depth sensor info returned")

si_color = lib.oniDeviceGetSensorInfo(dev, ONI_SENSOR_COLOR)
if si_color:
    si = si_color.contents
    print(f"  COLOR sensorType={si.sensorType} modes={si.numSupportedVideoModes}")
else:
    print("  NULL — no color sensor info returned")

print("\n=== Step 5: oniDeviceCreateStream(DEPTH) ===")
stream = ctypes.c_void_p()
s = lib.oniDeviceCreateStream(dev, ONI_SENSOR_DEPTH, ctypes.byref(stream))
print(f"  status={s} stream={stream.value:#x} {'OK' if s == ONI_STATUS_OK else 'FAIL: '+err()}")

if s == ONI_STATUS_OK:
    print("\n=== Step 6: oniStreamStart ===")
    s = lib.oniStreamStart(stream)
    print(f"  status={s} {'OK' if s == ONI_STATUS_OK else 'FAIL: '+err()}")

    if s == ONI_STATUS_OK:
        print("\n=== Step 7: oniStreamReadFrame ===")
        class OniFrame(ctypes.Structure):
            _fields_ = [
                ("dataSize", ctypes.c_int),
                ("data", ctypes.c_void_p),
                ("sensorType", ctypes.c_int),
                ("timestamp", ctypes.c_uint64),
                ("frameIndex", ctypes.c_int),
                ("width", ctypes.c_int),
                ("height", ctypes.c_int),
                ("videoMode", OniVideoMode),
                ("croppingEnabled", ctypes.c_int),
                ("cropOriginX", ctypes.c_int),
                ("cropOriginY", ctypes.c_int),
                ("stride", ctypes.c_int),
            ]
        lib.oniStreamReadFrame.argtypes = [
            ctypes.c_void_p,
            ctypes.POINTER(ctypes.POINTER(OniFrame)),
        ]
        lib.oniStreamReadFrame.restype = ctypes.c_int
        lib.oniFrameRelease.argtypes = [ctypes.POINTER(OniFrame)]
        lib.oniFrameRelease.restype = None

        p_frame = ctypes.POINTER(OniFrame)()
        s = lib.oniStreamReadFrame(stream, ctypes.byref(p_frame))
        print(f"  status={s} {'OK' if s == ONI_STATUS_OK else 'FAIL: '+err()}")
        if s == ONI_STATUS_OK and p_frame:
            f = p_frame.contents
            print(f"  frame: {f.width}x{f.height} dataSize={f.dataSize} sensorType={f.sensorType}")
            lib.oniFrameRelease(p_frame)

    print("\n=== Step 8: oniStreamStop ===")
    lib.oniStreamStop(stream)

# Cleanup
print("\n=== Step 9: Cleanup ===")
s = lib.oniDeviceClose(dev)
print(f"  oniDeviceClose: status={s}")
lib.oniShutdown()
print("  oniShutdown: done")
