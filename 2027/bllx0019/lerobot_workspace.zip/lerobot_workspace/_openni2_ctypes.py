"""
Minimal ctypes wrapper around the OpenNI2 C API.

Maps the function signatures from OniCAPI.h / OniCTypes.h exactly —
no dependencies on the broken 'openni' PyPI package.

Functions wrapped:
    oniInitialize / oniShutdown
    oniDeviceOpen / oniDeviceClose / oniDeviceGetInfo
    oniDeviceCreateStream (pass ONI_SENSOR_DEPTH / ONI_SENSOR_COLOR)
    oniStreamStart / oniStreamStop / oniStreamReadFrame
    oniFrameRelease  / oniStreamDestroy
    oniDeviceEnableDepthColorSync

OpenNI2.dll must be on the search path or set via openni2_lib_path.
"""

import ctypes
import ctypes.util
import os
import sys
from typing import Optional

import numpy as np


# ---------------------------------------------------------------------------
# ctypes type aliases (match OniCTypes.h / OniCEnums.h)
# ---------------------------------------------------------------------------

OniStatus   = ctypes.c_int
OniBool     = ctypes.c_int
OniDepthPixel = ctypes.c_uint16

# Handles (opaque pointers)
OniDeviceHandle = ctypes.c_void_p
OniStreamHandle = ctypes.c_void_p
OniCallbackHandle = ctypes.c_void_p

# Enums
ONI_STATUS_OK = 0
ONI_SENSOR_DEPTH   = 3
ONI_SENSOR_COLOR   = 2
ONI_PIXEL_FORMAT_DEPTH_1_MM = 100
ONI_IMAGE_REGISTRATION_DEPTH_TO_COLOR = 1

# API version (from OniVersion.h → ONI_CREATE_API_VERSION(major, minor))
# ONI_CREATE_API_VERSION(major, minor) = major * 1000 + minor
ONI_API_VERSION = 2003  # major=2, minor=3 → 2003


# ---------------------------------------------------------------------------
# Struct definitions (x64 layout matching OniCTypes.h)
# ---------------------------------------------------------------------------

class OniVideoMode(ctypes.Structure):
    _fields_ = [
        ("pixelFormat",   ctypes.c_int),
        ("resolutionX",   ctypes.c_int),
        ("resolutionY",   ctypes.c_int),
        ("fps",            ctypes.c_int),
    ]


class OniFrame(ctypes.Structure):
    """Matches OniFrame in OniCTypes.h (x64, MSVC default alignment)."""
    _fields_ = [
        ("dataSize",         ctypes.c_int),      # 0
        # 4 bytes implicit padding →
        ("data",             ctypes.c_void_p),    # 8
        ("sensorType",       ctypes.c_int),       # 16
        # 4 bytes implicit padding →
        ("timestamp",        ctypes.c_uint64),    # 24
        ("frameIndex",       ctypes.c_int),       # 32
        ("width",            ctypes.c_int),       # 36
        ("height",           ctypes.c_int),       # 40
        ("videoMode",        OniVideoMode),       # 44 (4×int = 16 bytes)
        ("croppingEnabled",  ctypes.c_int),       # 60
        ("cropOriginX",      ctypes.c_int),       # 64
        ("cropOriginY",      ctypes.c_int),       # 68
        ("stride",           ctypes.c_int),       # 72
    ]


class OniDeviceInfo(ctypes.Structure):
    _fields_ = [
        ("uri",          ctypes.c_char * 256),
        ("vendor",       ctypes.c_char * 256),
        ("name",         ctypes.c_char * 256),
        ("serialNumber", ctypes.c_char * 256),
        ("usbVendorId",  ctypes.c_uint16),
        ("usbProductId", ctypes.c_uint16),
        # implicit padding 4 bytes to align to 8
    ]


# ---------------------------------------------------------------------------
# Library discovery
# ---------------------------------------------------------------------------

def _find_lib() -> str:
    """Locate OpenNI2.dll / libOpenNI2.so on this platform."""
    if sys.platform == "win32":
        candidates = []

        # Priority 1: bundled samples/bin (verified working — has
        # OpenNI2\Drivers\orbbec.dll next to it)
        candidates.append(
            r"E:\ClaudeWorkspace\OpenNI_2.3.0.86_202210111950_"
            r"4c8f5aa4_beta6_windows\samples\bin\OpenNI2.dll"
        )

        # Priority 2: installed path (by install_openni2.ps1)
        redist64 = os.environ.get("OPENNI2_REDIST64", "")
        redist   = os.environ.get("OPENNI2_REDIST", "")
        if redist64:
            candidates.append(os.path.join(redist64, "OpenNI2.dll"))
        if redist:
            candidates.append(os.path.join(redist, "OpenNI2.dll"))

        # Priority 3: standard install locations
        candidates.extend([
            r"C:\Program Files\OpenNI2\Redist\OpenNI2.dll",
            r"C:\Program Files (x86)\OpenNI2\Redist\OpenNI2.dll",
        ])

        # Priority 4: fallback
        candidates.append(
            r"E:\ClaudeWorkspace\OpenNI_2.3.0.86_202210111950_"
            r"4c8f5aa4_beta6_windows\Win64-Release\sdk\libs\OpenNI2.dll"
        )
        candidates.append("OpenNI2.dll")  # PATH / cwd

        for c in candidates:
            if c and os.path.isfile(c):
                return c

        raise FileNotFoundError(
            "OpenNI2.dll not found.\n\n"
            "Run: powershell -ExecutionPolicy Bypass -File "
            "E:\\ClaudeWorkspace\\lerobot_workspace\\install_openni2.ps1\n"
            "Or set: $env:OPENNI2_REDIST64 = 'C:\\Program Files\\OpenNI2\\Redist'"
        )

    else:  # Linux / macOS
        for name in ["libOpenNI2.so", "libOpenNI2.so.0"]:
            path = ctypes.util.find_library(name)
            if path:
                return path
        for root in ["/usr/lib", "/usr/local/lib"]:
            for name in ["libOpenNI2.so", "libOpenNI2.so.0"]:
                p = os.path.join(root, name)
                if os.path.isfile(p):
                    return p
        raise FileNotFoundError(
            "libOpenNI2.so not found.\n"
            "Install Orbbec OpenNI2 SDK and run:\n"
            "  source /path/to/OpenNIDevEnvironment"
        )


# ---------------------------------------------------------------------------
# OpenNI2 C API wrapper
# ---------------------------------------------------------------------------

class OpenNI2:
    """Thin ctypes wrapper around OpenNI2 C API (OniCAPI.h)."""

    def __init__(self, lib_path: Optional[str] = None):
        self._lib_path = lib_path or _find_lib()
        self._lib = ctypes.cdll.LoadLibrary(self._lib_path)
        self._setup()

    # ---- setup signatures (OniCAPI.h) ----------------------------------

    def _setup(self):
        L = self._lib

        # General
        # ONI_C_API OniStatus oniInitialize(int apiVersion);
        L.oniInitialize.argtypes = [ctypes.c_int]
        L.oniInitialize.restype  = OniStatus

        # ONI_C_API void oniShutdown();
        L.oniShutdown.argtypes = []
        L.oniShutdown.restype  = None

        # Device
        # ONI_C_API OniStatus oniDeviceOpen(const char* uri, OniDeviceHandle* pDevice);
        L.oniDeviceOpen.argtypes = [ctypes.c_char_p, ctypes.POINTER(OniDeviceHandle)]
        L.oniDeviceOpen.restype  = OniStatus

        # ONI_C_API OniStatus oniDeviceClose(OniDeviceHandle device);
        L.oniDeviceClose.argtypes = [OniDeviceHandle]
        L.oniDeviceClose.restype  = OniStatus

        # ONI_C_API OniStatus oniDeviceGetInfo(OniDeviceHandle device, OniDeviceInfo* pInfo);
        L.oniDeviceGetInfo.argtypes = [OniDeviceHandle, ctypes.POINTER(OniDeviceInfo)]
        L.oniDeviceGetInfo.restype  = OniStatus

        # ONI_C_API OniStatus oniDeviceCreateStream(OniDeviceHandle device,
        #     OniSensorType sensorType, OniStreamHandle* pStream);
        L.oniDeviceCreateStream.argtypes = [
            OniDeviceHandle,
            ctypes.c_int,  # OniSensorType
            ctypes.POINTER(OniStreamHandle),
        ]
        L.oniDeviceCreateStream.restype = OniStatus

        # ONI_C_API OniStatus oniDeviceEnableDepthColorSync(OniDeviceHandle device);
        try:
            L.oniDeviceEnableDepthColorSync.argtypes = [OniDeviceHandle]
            L.oniDeviceEnableDepthColorSync.restype = OniStatus
        except AttributeError:
            pass  # optional — may not be in all builds

        # Stream
        # ONI_C_API OniStatus oniStreamStart(OniStreamHandle stream);
        L.oniStreamStart.argtypes = [OniStreamHandle]
        L.oniStreamStart.restype  = OniStatus

        # ONI_C_API void oniStreamStop(OniStreamHandle stream);
        L.oniStreamStop.argtypes = [OniStreamHandle]
        L.oniStreamStop.restype  = None

        # ONI_C_API OniStatus oniStreamReadFrame(OniStreamHandle stream, OniFrame** pFrame);
        L.oniStreamReadFrame.argtypes = [
            OniStreamHandle,
            ctypes.POINTER(ctypes.POINTER(OniFrame)),
        ]
        L.oniStreamReadFrame.restype = OniStatus

        # ONI_C_API void oniFrameRelease(OniFrame* pFrame);
        L.oniFrameRelease.argtypes = [ctypes.POINTER(OniFrame)]
        L.oniFrameRelease.restype  = None

        # ONI_C_API void oniStreamDestroy(OniStreamHandle stream);
        L.oniStreamDestroy.argtypes = [OniStreamHandle]
        L.oniStreamDestroy.restype  = None

    # ---- public API -----------------------------------------------------

    def initialize(self) -> None:
        status = self._lib.oniInitialize(ONI_API_VERSION)
        if status != ONI_STATUS_OK:
            raise RuntimeError(f"oniInitialize failed: status={status}")

    def shutdown(self) -> None:
        self._lib.oniShutdown()

    def device_open_any(self) -> OniDeviceHandle:
        """Open any connected device (uri=NULL)."""
        handle = OniDeviceHandle()
        status = self._lib.oniDeviceOpen(None, ctypes.byref(handle))
        if status != ONI_STATUS_OK:
            raise RuntimeError(
                f"oniDeviceOpen failed: status={status}. "
                f"Is the Astra Pro plugged in and driver installed?"
            )
        return handle

    def device_get_info(self, device: OniDeviceHandle) -> dict:
        info = OniDeviceInfo()
        status = self._lib.oniDeviceGetInfo(device, ctypes.byref(info))
        if status != ONI_STATUS_OK:
            raise RuntimeError(f"oniDeviceGetInfo failed: status={status}")
        return {
            "uri":          info.uri.decode("utf-8", errors="replace"),
            "vendor":       info.vendor.decode("utf-8", errors="replace"),
            "name":         info.name.decode("utf-8", errors="replace"),
            "serialNumber": info.serialNumber.decode("utf-8", errors="replace"),
            "usbVendorId":  info.usbVendorId,
            "usbProductId": info.usbProductId,
        }

    def device_close(self, device: OniDeviceHandle) -> None:
        self._lib.oniDeviceClose(device)

    def device_enable_depth_color_sync(self, device: OniDeviceHandle) -> None:
        try:
            self._lib.oniDeviceEnableDepthColorSync(device)
        except AttributeError:
            pass  # optional

    def create_depth_stream(self, device: OniDeviceHandle) -> OniStreamHandle:
        stream = OniStreamHandle()
        status = self._lib.oniDeviceCreateStream(
            device, ONI_SENSOR_DEPTH, ctypes.byref(stream)
        )
        if status != ONI_STATUS_OK:
            raise RuntimeError(
                f"oniDeviceCreateStream(DEPTH) failed: status={status}"
            )
        return stream

    def stream_start(self, stream: OniStreamHandle) -> None:
        status = self._lib.oniStreamStart(stream)
        if status != ONI_STATUS_OK:
            raise RuntimeError(f"oniStreamStart failed: status={status}")

    def stream_stop(self, stream: OniStreamHandle) -> None:
        self._lib.oniStreamStop(stream)

    def stream_read_frame(self, stream: OniStreamHandle):
        """Read one frame. Returns ctypes pointer to OniFrame or None on timeout."""
        p_frame = ctypes.POINTER(OniFrame)()
        status = self._lib.oniStreamReadFrame(stream, ctypes.byref(p_frame))
        if status != ONI_STATUS_OK:
            return None
        return p_frame

    def frame_release(self, p_frame) -> None:
        self._lib.oniFrameRelease(p_frame)

    def stream_destroy(self, stream: OniStreamHandle) -> None:
        self._lib.oniStreamDestroy(stream)

    # ---- helpers --------------------------------------------------------

    def read_depth_frame(self, stream: OniStreamHandle) -> Optional[np.ndarray]:
        """
        Read one depth frame and convert to float32 (H, W) mm array.
        Returns None on timeout/error.
        """
        p_frame = self.stream_read_frame(stream)
        if p_frame is None:
            return None
        try:
            frame = p_frame.contents
            w, h = frame.width, frame.height
            if frame.dataSize < w * h * 2:
                return None
            # Depth data: uint16 mm values
            buf_type = ctypes.c_uint16 * (w * h)
            buf = ctypes.cast(frame.data, ctypes.POINTER(buf_type))
            raw = np.frombuffer(buf.contents, dtype=np.uint16).reshape((h, w))
            return raw.astype(np.float32)
        finally:
            self.frame_release(p_frame)


# ---------------------------------------------------------------------------
# Quick test (run directly)
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print("OpenNI2 C API wrapper — test")
    print(f"DLL: {_find_lib()}")
    oni = OpenNI2()
    oni.initialize()
    print("oniInitialize OK")

    dev = oni.device_open_any()
    info = oni.device_get_info(dev)
    print(f"Device: {info}")

    # Try enabling depth-color sync
    oni.device_enable_depth_color_sync(dev)

    stream = oni.create_depth_stream(dev)
    oni.stream_start(stream)
    print("Depth stream started. Reading 10 frames...")

    for i in range(10):
        dpt = oni.read_depth_frame(stream)
        if dpt is not None:
            valid = dpt[dpt > 0]
            dmin = valid.min() if len(valid) > 0 else 0
            dmax = dpt.max()
            print(f"  Frame {i}: {dpt.shape}, range [{dmin:.0f}, {dmax:.0f}] mm")

    oni.stream_stop(stream)
    oni.stream_destroy(stream)
    oni.device_close(dev)
    oni.shutdown()
    print("Done — all OK")
