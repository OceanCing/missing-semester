"""
Dump exported function names from OpenNI2.dll.
Run this, send me the output, and I'll fix the ctypes wrapper.
"""
import ctypes
import sys
import os

# Find the DLL
redist = os.environ.get("OPENNI2_REDIST64", "")
dll_path = os.path.join(redist, "OpenNI2.dll") if redist else ""

if not os.path.isfile(dll_path):
    # Try bundled
    dll_path = (
        r"E:\ClaudeWorkspace\OpenNI_2.3.0.86_202210111950_"
        r"4c8f5aa4_beta6_windows\Win64-Release\sdk\libs\OpenNI2.dll"
    )

if not os.path.isfile(dll_path):
    print("OpenNI2.dll not found. Run install_openni2.ps1 first.")
    sys.exit(1)

print(f"DLL: {dll_path}\n")

# On Windows, use dumpbin if available, otherwise parse PE exports
try:
    import subprocess
    # Try dumpbin first
    result = subprocess.run(
        ["dumpbin", "/EXPORTS", dll_path],
        capture_output=True, text=True, timeout=10
    )
    if result.returncode == 0:
        print(result.stdout)
        sys.exit(0)
except Exception:
    pass

# Fallback: manual PE parsing to extract export names
# This is a simplified approach using ctypes
import struct

def read_exports(pe_path):
    """Minimal PE export parser — reads function names without pefile."""
    with open(pe_path, "rb") as f:
        data = f.read()

    # DOS header → PE offset
    if data[:2] != b"MZ":
        print("Not a valid PE file")
        return []
    pe_offset = struct.unpack_from("<I", data, 0x3C)[0]
    if data[pe_offset:pe_offset+4] != b"PE\x00\x00":
        print("PE signature not found")
        return []

    # Optional header
    coff = pe_offset + 4
    # Check if PE32+ (x64) or PE32 (x86)
    magic = struct.unpack_from("<H", data, coff + 20)[0]
    if magic == 0x20B:  # PE32+
        opt_header_size = 112
    else:
        opt_header_size = 96

    # Data directory: index 0 = Export Table
    dd_offset = coff + 20 + opt_header_size
    export_rva  = struct.unpack_from("<I", data, dd_offset)[0]
    export_size = struct.unpack_from("<I", data, dd_offset + 4)[0]

    if export_rva == 0 or export_size == 0:
        print("No export table in this DLL")
        return []

    # ---------- helper: RVA → file offset ----------
    sections_offset = dd_offset + 128  # 16 directories * 8 bytes
    sections = []
    for i in range(20):  # up to 20 sections
        name = data[sections_offset:sections_offset+8].rstrip(b"\x00").decode(errors="replace")
        virt_size    = struct.unpack_from("<I", data, sections_offset + 8)[0]
        virt_addr    = struct.unpack_from("<I", data, sections_offset + 12)[0]
        raw_size     = struct.unpack_from("<I", data, sections_offset + 16)[0]
        raw_offset   = struct.unpack_from("<I", data, sections_offset + 20)[0]
        if virt_size == 0:
            break
        sections.append((name, virt_addr, virt_size, raw_offset, raw_size))
        sections_offset += 40

    def rva_to_offset(rva):
        for name, vaddr, vsize, raw, rsize in sections:
            if vaddr <= rva < vaddr + vsize:
                return rva - vaddr + raw
        return None

    # ---------- parse export directory ----------
    off = rva_to_offset(export_rva)
    if off is None:
        print("Could not resolve export RVA")
        return []

    # IMAGE_EXPORT_DIRECTORY
    num_names      = struct.unpack_from("<I", data, off + 24)[0]
    num_functions  = struct.unpack_from("<I", data, off + 20)[0]
    address_rva    = struct.unpack_from("<I", data, off + 28)[0]  # RVA of EAT
    name_ptr_rva   = struct.unpack_from("<I", data, off + 32)[0]  # RVA of name pointer table
    ordinal_rva    = struct.unpack_from("<I", data, off + 36)[0]  # RVA of ordinal table

    names = []
    name_ptr_off = rva_to_offset(name_ptr_rva)
    ordinal_off  = rva_to_offset(ordinal_rva)

    if name_ptr_off is None or ordinal_off is None:
        print("Could not resolve export tables")
        return []

    for i in range(num_names):
        # Ordinal for this name
        ord_idx = struct.unpack_from("<H", data, ordinal_off + i * 2)[0]
        # Pointer to name string
        name_rva = struct.unpack_from("<I", data, name_ptr_off + i * 4)[0]
        name_off = rva_to_offset(name_rva)
        if name_off is None:
            continue
        # Null-terminated string
        end = data.find(b"\x00", name_off)
        name = data[name_off:end].decode("ascii", errors="replace")
        names.append((ord_idx, name))

    return names

print("Parsing export table...\n")
exports = read_exports(dll_path)

if not exports:
    print("No exports found or parse failed.")
    sys.exit(1)

# Look for OpenNI-related names
print(f"Total exported names: {len(exports)}\n")
print("--- Functions containing 'oni' or 'Oni' ---")
for idx, name in exports:
    if "ni" in name.lower() or "depth" in name.lower() or "stream" in name.lower():
        print(f"  [{idx}] {name}")

print("\n--- All exports (first 60) ---")
for idx, name in exports[:60]:
    print(f"  [{idx}] {name}")

if len(exports) > 60:
    print(f"  ... and {len(exports) - 60} more")
