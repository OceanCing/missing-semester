"""
Orbbec Astra Pro hardware check.

Uses _openni2_ctypes.py (corrected OpenNI2 C API wrapper) to verify
depth capture.  Colour is checked via standard OpenCV UVC.

Usage:
    python check_astra.py
"""

import sys
from typing import Optional


def check_openni2_depth() -> Optional[str]:
    """Verify OpenNI2 can find the Astra Pro and read depth frames."""
    print("=" * 55)
    print("1. Checking OpenNI2 depth interface (C API / ctypes)...")

    try:
        from _openni2_ctypes import OpenNI2
    except ImportError:
        print("   FAILED: _openni2_ctypes.py not found.")
        print("   Make sure it's in the same folder.")
        return None

    try:
        oni = OpenNI2()
        oni.initialize()
        print("   oniInitialize OK")
    except FileNotFoundError as e:
        print(f"   FAILED: OpenNI2 DLL not found.")
        print()
        print("   === How to fix on Windows ===")
        print("   Run the installer script as Administrator:")
        print("     powershell -ExecutionPolicy Bypass -File")
        print("       E:\\ClaudeWorkspace\\lerobot_workspace\\install_openni2.ps1")
        print()
        print(f"   Details: {e}")
        return None
    except RuntimeError as e:
        print(f"   FAILED: {e}")
        return None

    try:
        dev = oni.device_open_any()
        info = oni.device_get_info(dev)
        print(f"   Device: {info.get('name', '?')}")
        print(f"   Vendor: {info.get('vendor', '?')}")
        print(f"   Serial: {info.get('serialNumber', '?')}")
    except RuntimeError as e:
        print(f"   FAILED: {e}")
        print("   - Is the Astra Pro plugged in via USB?")
        print("   - Did you install the Astra driver?")
        print("     Run: E:\\ClaudeWorkspace\\astra-win32-driver-4.3.0.22\\")
        print("          SensorDriver_V4.3.0.22.exe")
        oni.shutdown()
        return None

    # Enable depth-colour sync if supported
    try:
        oni.device_enable_depth_color_sync(dev)
        print("   Depth-colour sync enabled")
    except Exception:
        pass

    # Test depth stream
    try:
        stream = oni.create_depth_stream(dev)
        oni.stream_start(stream)
        print("   Depth stream started")

        import numpy as np
        samples = []
        for _ in range(10):
            dpt = oni.read_depth_frame(stream)
            if dpt is not None:
                valid = dpt[dpt > 0]
                if len(valid) > 0:
                    samples.append((valid.min(), valid.max()))

        if samples:
            mins = [s[0] for s in samples]
            maxs = [s[1] for s in samples]
            print(f"   Depth frames: {len(samples)}/10 OK")
            print(f"   Depth range: [{min(mins):.0f}, {max(maxs):.0f}] mm")
        else:
            print("   WARNING: No valid depth pixels in any frame")
            print("   Try pointing the camera at something 0.5–2m away")

        oni.stream_stop(stream)
        oni.stream_destroy(stream)
        oni.device_close(dev)
        oni.shutdown()
        return "openni2_ctypes"

    except Exception as e:
        print(f"   FAILED: {type(e).__name__}: {e}")
        try:
            oni.device_close(dev)
            oni.shutdown()
        except Exception:
            pass
        return None


def check_color_uvc() -> Optional[int]:
    """Check UVC colour stream via OpenCV."""
    print()
    print("=" * 55)
    print("2. Checking UVC colour stream (OpenCV)...")

    try:
        import cv2
    except ImportError:
        print("   FAILED: opencv-python not installed")
        return None

    for idx in range(4):
        cap = cv2.VideoCapture(idx)
        if cap.isOpened():
            ret, frame = cap.read()
            if ret:
                print(f"   Found at index {idx}: {frame.shape}")
                cap.release()
                return idx
            cap.release()

    print("   No UVC colour stream found on indices 0–3")
    return None


def main():
    print("Orbbec Astra Pro — Hardware Check")
    print("=" * 55)
    print()

    depth_backend = check_openni2_depth()
    uvc_idx = check_color_uvc()

    print()
    print("=" * 55)
    print("Summary:")

    if depth_backend:
        print(f"  [PASS] Depth backend: {depth_backend}")
    else:
        print("  [FAIL] No depth backend available")

    if uvc_idx is not None:
        print(f"  [PASS] UVC colour at index {uvc_idx}")
    else:
        print("  [FAIL] No UVC colour stream")

    if depth_backend and uvc_idx is not None:
        print()
        print("Ready!  Use the adapter:")
        print()
        print("  from configuration_astra import OrbbecAstraCameraConfig")
        print("  from orbbec_astra_camera import OrbbecAstraCamera")
        print()
        print("  config = OrbbecAstraCameraConfig(color_index=0)")
        print("  with OrbbecAstraCamera(config) as cam:")
        print("      color, depth = cam.read_both()")

    sys.exit(0 if depth_backend and uvc_idx is not None else 1)


if __name__ == "__main__":
    main()
