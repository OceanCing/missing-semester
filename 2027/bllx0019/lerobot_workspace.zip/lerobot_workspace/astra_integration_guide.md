# Orbbec Astra Pro → LeRobot 集成指南

## 背景

LeRobot 的深度相机目前只官方支持 Intel RealSense D400/D500 系列。Orbbec Astra Pro
没有官方适配，但通过自定义适配器可以接入。

**原理**：Astra Pro 用 Orbbec SDK v1.x（底层是 OpenNI 协议）驱动深度和彩色流，
适配器将 Orbbec SDK 的 Pipeline API 包装成 LeRobot 风格的相机接口。

华南师大追光团队已将 Orbbec Gemini2 成功接入 LeRobot（源码已开源），
这条路被验证是可行的。

---

## 为什么 `pip install openni` 不行

PyPI 上的 `openni` 包只有一个 `py2-none-any.whl`（Python 2），在 Python 3 环境下
无法直接安装。这是 Orbbec 老设备的遗留问题。

**替代方案**：使用 `pyorbbecsdk`（Orbbec 官方 Python SDK v1.x 分支），
它通过 pybind11 封装了 Orbbec SDK 的 C++ API，支持 Python 3。

---

## Windows 安装（完整步骤）

### 前提
- Windows 10 或 11
- Python 3.9–3.11（推荐你的 `lerobot` conda 环境）
- 管理员权限（安装 SDK 时需要）

### 第 1 步：安装 Orbbec SDK 基础包

Orbbec SDK v1.10.x 提供底层驱动和 DLL，pyorbbecsdk 依赖它。

下载地址：https://github.com/orbbec/OrbbecSDK/releases

找到 **v1.10.x** 的 Windows 安装包（`.exe`），下载并运行。

安装完成后：
- 设备管理器中应能看到 Orbbec 设备
- SDK 的 bin 目录会加入 PATH（包含所需的 DLL）

验证：插上 Astra Pro 后，设备管理器里应出现 "Orbbec" 相关设备。

### 第 2 步：安装 C++ 编译工具

pyorbbecsdk 没有 Windows 预编译 wheel，需要从源码构建。

1. 下载 [Visual Studio 2022 Community](https://visualstudio.microsoft.com/vs/community/)（免费）
2. 运行安装器，勾选：
   - **"使用 C++ 的桌面开发"**（Desktop development with C++）
   - 确保 **Windows 10 SDK** 和 **CMake 的 C++ 工具** 在右侧已勾选
3. 完成安装（约 6–8 GB）

### 第 3 步：构建 pyorbbecsdk

在 **PowerShell** 中执行（建议在 `E:\ClaudeWorkspace\lerobot_workspace\` 下操作）：

```powershell
# 激活你的 lerobot conda 环境
conda activate lerobot

# 安装构建依赖
pip install pybind11 numpy opencv-python setuptools wheel

# 克隆 pyorbbecsdk
cd E:\ClaudeWorkspace\lerobot_workspace
git clone https://github.com/orbbec/pyorbbecsdk
cd pyorbbecsdk
git checkout v1.3.4

# 创建构建目录
mkdir build
cd build

# 配置 CMake（使用 VS 2022，x64）
cmake .. -G "Visual Studio 17 2022" -A x64

# 编译（Release 模式）
cmake --build . --config Release

# 安装到本地目录
cmake --install . --prefix ../install --config Release

# 将 install/lib 加入 PYTHONPATH
# 每次使用前执行，或添加到系统环境变量
$env:PYTHONPATH = "E:\ClaudeWorkspace\lerobot_workspace\pyorbbecsdk\install\lib;$env:PYTHONPATH"
```

### 第 4 步：验证安装

```powershell
cd E:\ClaudeWorkspace\lerobot_workspace
python check_astra.py
```

如果成功，你会看到类似：
```
  [PASS] Depth backend: pyorbbecsdk
  [PASS] UVC colour at index 0
```

---

## Linux 安装（简要）

```bash
# 安装 Orbbec SDK v1.10.x
# https://github.com/orbbec/OrbbecSDK/releases → 下载 .deb 或 .tar.gz

# 构建 pyorbbecsdk
git clone https://github.com/orbbec/pyorbbecsdk
cd pyorbbecsdk && git checkout v1.3.4
pip install pybind11 numpy opencv-python
mkdir build && cd build
cmake -Dpybind11_DIR=`pybind11-config --cmakedir` ..
make -j$(nproc)
make install

# 如果 openni 后端也要用（可选）
# sudo apt install openni2-utils libopenni2-dev
# pip install openni  # 从 sdist 编译，需要系统有 OpenNI2 头文件
```

---

## 在 LeRobot 中使用

### 方式 A：直接使用适配器（推荐）

```python
from configuration_astra import OrbbecAstraCameraConfig
from orbbec_astra_camera import OrbbecAstraCamera

config = OrbbecAstraCameraConfig(
    backend="pyorbbecsdk",
    fps=30,
    width=640,
    height=480,
    use_depth=True,
    focus_range=(200, 5000),
)

with OrbbecAstraCamera(config) as cam:
    # 同步获取彩色+深度（来自同一帧集，pyorbbecsdk 提供帧同步）
    color, depth = cam.read_both()

    # 或分别获取
    color = cam.read()         # (H, W, 3) uint8
    depth = cam.read_depth()   # (H, W) float32, 单位毫米

    # 异步非阻塞
    color = cam.async_read(timeout_ms=200)
```

### 方式 B：替换 LeRobot 数据采集脚本中的相机

在 `lerobot/scripts/control_robot.py` 或你的采集脚本中：

```python
# 原始代码 (RealSense):
# from lerobot.cameras.realsense.camera_realsense import RealSenseCamera
# from lerobot.cameras.realsense.configuration_realsense import RealSenseCameraConfig
# camera = RealSenseCamera(config)

# 替换为:
from orbbec_astra_camera import OrbbecAstraCamera
from configuration_astra import OrbbecAstraCameraConfig

astra_config = OrbbecAstraCameraConfig(
    backend="pyorbbecsdk",
    width=640, height=480, fps=30,
    use_depth=True,
)
camera = OrbbecAstraCamera(astra_config)
# camera.read() 和 camera.read_depth() 与 RealSenseCamera 接口一致
```

### 方式 C：集成到 LeRobot 源码（进阶）

如果需要 `lerobot-find-cameras` 识别 Astra Pro：

1. 复制适配器到 LeRobot 源码目录：
   ```
   copy orbbec_astra_camera.py → src/lerobot/cameras/orbbec/
   copy configuration_astra.py  → src/lerobot/cameras/orbbec/
   ```
2. 修改 `src/lerobot/cameras/utils.py`（第 40 行附近），添加 Astra Pro 设备发现逻辑
3. 修改 `src/lerobot/cameras/__init__.py`（第 18 行附近），注册相机类型

具体修改参考 Seeed Wiki 上华南师大给 Gemini2 做的教程。

---

## 已知限制

| 问题 | 说明 |
|------|------|
| **构建依赖重** | Windows 需要 VS 2022 + CMake 来编译 pyorbbecsdk。Orbbec 暂未提供 v1.x 的预编译 wheel |
| **USB 带宽** | Astra Pro 是 USB 2.0，高分辨率下双流可能遇到瓶颈。建议 640×480 |
| **室外性能** | 结构光方案在室外强光下深度质量下降明显 |
| **"limited maintenance"** | Orbbec 对 Astra Pro 的 v1.x SDK 只提供关键 bug 修复，不再加新功能 |

---

## 备选方案

如果 Astra Pro 的深度质量或安装复杂度不满足需求，可考虑：

- **Orbbec Gemini 2** — 已有社区 LeRobot 适配（华南师大追光团队开源）
- **Orbbec Astra 2** — UVC 协议，可用 pyorbbecsdk2 (`pip install pyorbbecsdk2`)，即装即用
- **Orbbec Gemini 330 系列** — Orbbec 官方推荐的新一代，pyorbbecsdk2 全支持
- **Intel RealSense D435** — LeRobot 原生支持，最省心

---

## 参考链接

- [Orbbec SDK GitHub](https://github.com/orbbec/OrbbecSDK)
- [pyorbbecsdk GitHub (v1.x)](https://github.com/orbbec/pyorbbecsdk)
- [pyorbbecsdk Windows 构建文档](https://github.com/orbbec/pyorbbecsdk/blob/main/docs/README_EN.md)
- [华南师大 Gemini2 接入 LeRobot 教程](https://wiki.seeedstudio.com/cn/lerobot_so100m/)
- [LeRobot 相机系统文档](https://huggingface.co/docs/lerobot/cameras)
