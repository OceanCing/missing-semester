# Orbbec Astra Pro 深度相机接入 LeRobot 项目总结

## 项目目标

使 **Orbbec Astra Pro** 深度相机（仅支持 OpenNI2 协议）能够接入 **HuggingFace LeRobot** 机器人学习框架，实现彩色+深度的多机位数据采集，以及点云数据参与 **ACT（Action Chunking Transformer）模型训练**。

硬件环境：SO-101 机械臂（Follower COM7 + Leader COM8）、Orbbec Astra Pro 深度相机、多台普通 USB 摄像头、Intel Arc B580 显卡、Windows 11。

---

## 一、开发历程

### 阶段 1：调研与可行性验证

查阅 LeRobot 官方文档、DeepWiki 和社区教程，确认：
- LeRobot 深度相机**仅支持** Intel RealSense D400/D500 系列
- 华南师大追光团队已将 Orbbec Gemini 2 成功接入（证明路径可行），但 Astra Pro 不同——它是更早期的 OpenNI2 设备
- `pyorbbecsdk` 的 v2.x 分支不支持 Astra Pro，v1.x 支持 Astra+ 和 Astra Pro Plus 但**不支持** Astra Pro
- PyPI 的 `openni` 包只有一个 `py2-none-any.whl`，Python 3 无法安装
- Orbbec 提供的 OpenNI2 SDK v2.3.0.86 包含完整的 C API 头文件（`OniCAPI.h`、`OniCTypes.h`、`OniCEnums.h`），可以直接通过 ctypes 调用

### 阶段 2：ctypes 封装开发与调试

**核心突破**：手写 ctypes 封装绕过所有不兼容的 Python 包，直接调用系统安装的 `OpenNI2.dll`。

遇到的坑：
1. **函数名不匹配**：Orbbec 修改过的 OpenNI2 使用的是标准 C API（`oniDeviceOpen`、`oniDeviceCreateStream`、`oniStreamReadFrame` 等），与 open-source OpenNI2 的旧文档不完全一致。通过阅读 SDK 头文件 `OniCAPI.h` 和编写 `dump_exports.py` 解析 DLL 导出表定位正确函数名
2. **DLL 路径问题**：SDK `samples\bin\OpenNI2.dll` 和 `Win64-Release\sdk\libs\OpenNI2.dll` 都能加载，但前者旁有配套的 `OpenNI2\Drivers\orbbec.dll`，后者缺了这个驱动。优先加载前者才能正常工作
3. **x64 结构体对齐**：`OniFrame` 结构体在 x64 MSVC 下有隐式 padding，ctypes 定义必须精确匹配，否则读取 `width`/`height`/`dataSize` 时得到错误值
4. **`oniDeviceCreateStream(DEPTH)` 返回 status=1（ONI_STATUS_ERROR）**：在 `C:\Program Files\OpenNI2\Redist\` 路径下加载的 DLL 会报这个错。原因是在该目录下缺少配套的 `OpenNI2\Drivers\orbbec.dll`。最终确认优先使用 `samples\bin\OpenNI2.dll` 并设置搜索优先级

**验证工具链**：
- `debug_astra.py`：逐步调用每个 C API，打印 `oniGetExtendedError()` 定位失败点
- `DepthReaderPoll.exe`：SDK 自带的 C++ 示例，验证硬件本身工作正常（~723mm 深度值）
- `dump_exports.py`：手写 PE 解析器，提取 DLL 导出的所有 58 个函数名

### 阶段 3：LeRobot 集成

编写了三个符合 LeRobot `Camera` 抽象基类的相机类：
1. **`OrbbecAstraCamera`**（type=`orbbec_astra`）：彩色帧 + 深度流初始化。继承 `Camera`，实现 `read()`、`async_read()`、`connect()`、`disconnect()` 等全部抽象方法。彩色通过 OpenCV VideoCapture（后台线程），深度通过共享的 OpenNI2 连接
2. **`OrbbecAstraDepthCamera`**（type=`orbbec_astra_depth`）：JET 彩色深度映射图，复用共享 OpenNI2 连接
3. **`OrbbecAstraDepthRawCamera`**（type=`orbbec_astra_depth_raw`）：uint16 深度值无损编码为 3 通道 uint8

通过 `@CameraConfig.register_subclass` 装饰器注册到 draccus 选择系统，可在命令行中通过 `{type: orbbec_astra, ...}` 直接使用。

遇到的坑：
1. **OpenCV MSMF 后端冲突**：Astra Pro 的 UVC 彩色流在 OpenNI2 初始化后被 MSMF 后端锁住（`OnReadSample error: -1072873821`）。解决：① 先初始化 OpenNI2 再启动彩色读取线程（与 SDK 示例 `AstroProD2C.cpp` 的顺序一致）；② 添加 DSShow 后端作为回退；③ 背景读取线程在连续 10 次失败后自动重连彩色流
2. **单例深度连接**：三个相机共享同一个 OpenNI2 连接（模块级变量 `_shared_oni` + 引用计数），`orbbec_astra` 负责初始化，两个深度相机复用，最后一个断开时释放
3. **import 路径错误**：`pointcloud_processor.py` 从错误的模块导入了 `ObservationProcessorStep`。`lerobot.processor.core` 没有这个类，它在 `lerobot.processor.pipeline` 里。修正为 `from .pipeline import ObservationProcessorStep`

### 阶段 4：录制体验优化

1. **空格键手动分段**：修改 `control_utils.py`，增加 Space 键快速分段功能
2. **Rerun 可视化**：通过 `--display_data=true` 在桌面弹窗查看实时画面
3. **数据集存储路径自定义**：通过 `--dataset.root` 指定存储位置（如 `E:\lerobot_images`）
4. **深度流镜像控制**：通过 `ONI_STREAM_PROPERTY_MIRRORING`（property ID=7）开关硬件镜像

### 阶段 5：点云训练 pipeline（Plan B）

**目标**：让精确的深度值参与 ACT 模型训练。

**数据流**：
```
录制 → depth_raw (编码 uint16)
训练 → PointCloudProcessorStep
        ├── 解码 depth_raw → 重建 uint16 深度值 (mm)
        ├── 用深度内参反投影 → (H, W, 3) XYZ 坐标图
        ├── 归一化 XYZ 到 [-1, 1]
        ├── 双线性插值对齐彩色分辨率
        └── 替换 depth 特征为 XYZ 张量 → 送入 ACT 模型
```

**不需要手动 D2C 标定**：Astra Pro 的出厂标定参数烧录在固件中，通过 `oniDeviceGetProperty(OBEXTENSION_ID_CAM_PARAMS=14)` 直接读取。包含深度/彩色内参、旋转矩阵、平移向量和畸变系数。

### 阶段 6：数据集体积优化

1. **深度可视化从 JET 改灰度**：`depth_viz` 的 `_depth_to_colormap()` 从 `cv2.applyColorMap(d, cv2.COLORMAP_JET)` 改为 `np.stack([d,d,d], axis=-1)` 单通道灰度×3。视频编码器对三个完全相同通道的压缩效率极高，体积缩到约 1/3，训练效果完全不变——ACT 的卷积层对灰度/彩色图提取的特征没有本质区别
2. **新增 JET 彩色深度通道**：添加 `orbbec_astra_depth_color` 类型，继承 `OrbbecAstraDepthCameraConfig` 并将 `mode` 设为 `"color"`。供 Rerun 直观查看用，不用于训练
3. **`mode` 参数**：`OrbbecAstraDepthCameraConfig` 新增 `mode: str = "gray"` 参数——`"gray"` 输出单通道灰度堆叠三通道（省空间），`"color"` 输出 JET 彩色映射图（直观查看）。`orbbec_astra_depth` 默认 `"gray"`，`orbbec_astra_depth_color` 默认 `"color"`

---

## 二、完整文件清单

### LeRobot 源码树中的文件（`C:\Users\bllx\lerobot\`）

| 文件 | 变更 | 说明 |
|------|------|------|
| `src/lerobot/cameras/orbbec_astra/__init__.py` | **新增** | 模块入口，导出 `OrbbecAstraCamera`、`OrbbecAstraDepthCamera`、`OrbbecAstraDepthRawCamera`、`get_calibration_params` |
| `src/lerobot/cameras/orbbec_astra/_openni2_ctypes.py` | **新增** | 核心 ctypes 封装（~350 行）。按 `OniCAPI.h` 声明加载 `OpenNI2.dll`，包装 15 个 C API 函数。x64 MSVC 结构体对齐。DLL 搜索优先级：`samples\bin\` > `OPENNI2_REDIST64` > `C:\Program Files\` > 本地回退。包含 `device_get_camera_params()` 读取出厂标定和 `set_stream_mirror()` 控制镜像 |
| `src/lerobot/cameras/orbbec_astra/configuration_orbbec_astra.py` | **新增** | 四个 `@CameraConfig.register_subclass` 配置类：`OrbbecAstraCameraConfig`、`OrbbecAstraDepthCameraConfig`、`OrbbecAstraDepthColorCameraConfig`、`OrbbecAstraDepthRawCameraConfig`。`OrbbecAstraDepthCameraConfig` 含 `mode` 参数（`"gray"` vs `"color"`），`OrbbecAstraDepthColorCameraConfig` 继承并默认 `"color"` |
| `src/lerobot/cameras/orbbec_astra/camera_orbbec_astra.py` | **新增** | 四个相机实现类（~680 行）。`OrbbecAstraCamera` 完全实现 `Camera` 抽象基类。`OrbbecAstraDepthCamera` 的 `_depth_to_colormap()` 根据 `mode` 参数输出灰度×3 或 JET 彩色。模块级共享 OpenNI2 单例 + 引用计数。`get_calibration_params()` 工具函数 |
| `src/lerobot/cameras/utils.py` | **修改** | `make_cameras_from_configs()` 新增 `orbbec_astra`、`orbbec_astra_depth`、`orbbec_astra_depth_color`、`orbbec_astra_depth_raw` 四个分支 |
| `src/lerobot/scripts/lerobot_record.py` | **修改** | import 新配置类 + `save_episode()` 前增加空 episode 缓冲区保护——当录制 loop 中途 crash 缓冲区为空时，打印警告跳过而非抛异常崩溃，自动进入下一个 episode |
| `src/lerobot/utils/control_utils.py` | **修改** | `init_keyboard_listener()` 中新增 Space 键分段功能 |
| `src/lerobot/processor/pointcloud_processor.py` | **新增** | `PointCloudProcessorStep`（`@ProcessorStepRegistry.register`）和 `save_calibration_to_file()` 工具函数。实现深度解码、反投影、归一化、分辨率对齐 |
| `src/lerobot/processor/__init__.py` | **修改** | import `pointcloud_processor` 使其注册 |

### 项目工作区文件（`E:\ClaudeWorkspace\lerobot_workspace\`）

| 文件 | 用途 | 当前状态 |
|------|------|---------|
| `astra_pro_lerobot_report.md` | **本文档**，完整项目总结 | 最终版 |
| `recording_config_guide.md` | 录制配置指南（11 个章节），包含 6 种配置方案、相机参数表、故障排查、点云训练速查 | 持续使用 |
| `astra_integration_guide.md` | 早期集成指南，包含 Windows 安装步骤和环境准备 | 早期版本，被 `astra_pro_lerobot_report.md` 和 `recording_config_guide.md` 取代 |
| `_openni2_ctypes.py` | ctypes 封装独立版，与 LeRobot 源码中的版本同步，可独立运行测试 | 调试用 |
| `orbbec_astra_camera.py` | 早期适配器原型，含 `_PyOrbbecAstraCamera`、`_OpenNIAstraCamera`、`_MockAstraCamera` 三个后端 | 原型（已废弃），逻辑已迁移到 LeRobot 源码 |
| `configuration_astra.py` | 早期配置类原型，含 `backend: Literal["pyorbbecsdk", "openni"]` 参数 | 原型（已废弃），最终版在 LeRobot 源码中 |
| `check_astra.py` | 硬件检测脚本，检查 OpenNI2 深度接口和 UVC 彩色流 | 调试用，首次安装时运行一次 |
| `debug_astra.py` | 逐步 C API 调试脚本，每步打印状态码和 `oniGetExtendedError()` | 调试用，定位 `oniDeviceCreateStream` 失败 |
| `dump_exports.py` | PE 文件导出符号解析器，手写解析 `OpenNI2.dll` 的 58 个导出函数名 | 调试用，一次性使用 |
| `install_openni2.ps1` | Windows 自动安装脚本（需管理员权限），复制 DLL 到 `C:\Program Files\OpenNI2\Redist\` 并设 `OPENNI2_REDIST64` 环境变量 | 首次安装时运行一次 |

### 依赖的外部资源（`E:\ClaudeWorkspace\`）

| 路径 | 说明 |
|------|------|
| `OpenNI_2.3.0.86_202210111950_4c8f5aa4_beta6_windows\` | Orbbec OpenNI2 SDK v2.3.0.86-beta6，包含 OpenNI2.dll、orbbec.dll、C API 头文件、预编译示例程序 |
| `astra-win32-driver-4.3.0.22\SensorDriver_V4.3.0.22.exe` | Astra Pro 的 Windows USB 驱动安装包 |

---

## 三、系统架构

```
                    ┌──────────────────────────────────┐
                    │          LeRobot CLI              │
                    │     lerobot-record                │
                    │     --robot.cameras='{...}'       │
                    └──────────┬───────────────────────┘
                               │ draccus 解析
                               ▼
                    ┌──────────────────────────────────┐
                    │     make_cameras_from_configs()    │
                    │        (cameras/utils.py)          │
                    │  cfg.type == "orbbec_astra" 等    │
                    └──────────┬───────────────────────┘
                               │
            ┌──────────────────┼──────────────────┐
            ▼                  ▼                  ▼
   OrbbecAstraCamera   OrbbecAstraDepth   OrbbecAstraDepth
     (彩色 UVC)         Camera (JET)      RawCamera (uint16)
            │                  │                  │
            │ connect()        │ connect()        │ connect()
            │ ├─ OpenCV         │ └─ refcount++    │ └─ refcount++
            │    VideoCapture   │                  │
            │ └─ _init_shared   │                  │
            │    _openni()      │                  │
            │                  │                  │
            └──────────┬───────┴──────────────────┘
                       │ 共享同一 OpenNI2 连接
                       ▼
            ┌──────────────────────────┐
            │      _openni2_ctypes     │
            │  (ctypes → OpenNI2.dll)  │
            │                          │
            │  oniInitialize           │
            │  oniDeviceOpen           │
            │  oniDeviceCreateStream   │
            │  oniStreamStart          │
            │  oniStreamReadFrame      │
            │  oniDeviceGetProperty    │
            │  oniStreamSetProperty    │
            │  ...                     │
            └──────────┬───────────────┘
                       │
                       ▼
            ┌──────────────────────────┐
            │    OpenNI2.dll (x64)     │
            │  + OpenNI2\Drivers\      │
            │    orbbec.dll            │
            └──────────┬───────────────┘
                       │ USB
                       ▼
            ┌──────────────────────────┐
            │   Orbbec Astra Pro       │
            │   深度: 640×480 结构光    │
            │   彩色: 最高 1920×1080    │
            └──────────────────────────┘
```

---

## 四、相机类型对照表

| type 值 | 输出 | 编码方式 | Rerun 显示 | 训练用途 |
|---------|------|---------|-----------|---------|
| `orbbec_astra` | 彩色帧（实际 1280×720 或 640×480） | 标准 RGB/BGR | 正常彩色画面 | 主视觉输入 |
| `orbbec_astra_depth` | 灰度深度图（640×480） | 单通道灰度×3 | 黑白深度画面 | 轻量训练，文件小 |
| `orbbec_astra_depth_color` | JET 深度映射图（640×480） | 3ch uint8 蓝→绿→红 | 直观彩色深度 | 仅可视化 |
| `orbbec_astra_depth_raw` | 原始深度值（640×480） | Ch0=低字节, Ch1=高字节, Ch2=0 | 暗蓝暗绿噪声 | **点云反投影** |
| `opencv` | 普通摄像头彩色帧 | 标准 RGB/BGR | 正常彩色画面 | 辅助视角 |

## 四-B、深度相机配置参数表

### `orbbec_astra`（彩色 + 深度流初始化）

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `color_index` | 0 | UVC 彩色流设备索引号 |
| `use_depth` | true | 是否初始化共享深度流（必须为 true） |
| `mirror` | false | 深度流左右镜像 |
| `width` | 640 | 目标分辨率宽（自动适配实际值） |
| `height` | 480 | 目标分辨率高 |
| `fps` | 30 | 帧率 |
| `color_mode` | rgb | `rgb` 或 `bgr` |
| `focus_range` | (200, 5000) | 深度有效范围 |

### `orbbec_astra_depth` / `orbbec_astra_depth_color`（可视化深度）

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `mode` | `"gray"`（depth）/ `"color"`（depth_color） | 渲染模式 |
| `width` | 640 | 输出宽 |
| `height` | 480 | 输出高 |
| `fps` | 30 | 帧率 |
| `min_depth_mm` | 250 | 深度截断下限 |
| `max_depth_mm` | 1300 | 深度截断上限 |

### `orbbec_astra_depth_raw`（原始深度，训练用）

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `width` | 640 | 输出宽 |
| `height` | 480 | 输出高 |
| `fps` | 30 | 帧率 |
| `min_depth_mm` | 250 | 深度截断下限 |
| `max_depth_mm` | 1300 | 深度截断上限 |

---

## 五、关键技术决策

### 为什么不用 pyorbbecsdk
Astra Pro **不在** pyorbbecsdk v1.x 的支持列表中（仅支持 Astra+、Astra Pro Plus、Astra 2）。v2.x 完全不支持 OpenNI 协议设备。

### 为什么不用 pip install openni
PyPI 的 `openni` 包只有一个 `py2-none-any.whl`，仅兼容 Python 2。Python 3 下无法从 sdist 编译（需要系统 OpenNI2 头文件和 C 编译器）。

### ctypes 方案的优势
- 零外部 Python 依赖（除了 numpy 和 opencv-python）
- 直接映射 C API 头文件声明，不经过任何中间层
- 与 LeRobot 的 OpenCV 相机架构完全解耦
- 可运行时加载任何路径的 `OpenNI2.dll`

### 共享 OpenNI2 连接
三个相机类型共享一个模块级 OpenNI2 连接（引用计数管理），避免：
- 重复调用 `oniInitialize` 导致的资源冲突
- 多次打开设备造成的 USB 带宽竞争
- `oniDeviceEnableDepthColorSync` 只能调用一次的限制

### 深度范围预设
深度范围通过 `orbbec_astra_depth` / `orbbec_astra_depth_raw` 配置类中的 `min_depth_mm` / `max_depth_mm` 参数预设，默认 250 / 1300 mm。所有深度通道统一使用配置值，无需额外的运行时覆盖机制。

---

## 六、录制命令

完整启动命令和所有配置方案详见《[录制配置指南](computer://E:\ClaudeWorkspace\lerobot_workspace\recording_config_guide.md)》→「启动命令模板」及「常用配置方案」章节。

### 从中断点接续录制

录制中途崩溃或手动停止后，加 `--resume=true` 从最后一个完整 episode 之后继续。所有其他参数和首次录制完全相同：

```powershell
lerobot-record `
    --resume=true `
    --robot.type=so101_follower `
    --robot.port=COM7 `
    --robot.id=follower_arm `
    --robot.cameras='{
        color: {type: orbbec_astra, color_index: 2, use_depth: true, mirror: false, width: 640, height: 480, fps: 30},
        depth_viz: {type: orbbec_astra_depth, width: 640, height: 480, fps: 30},
        depth_viz_color: {type: orbbec_astra_depth_color, width: 640, height: 480, fps: 30},
        depth_raw: {type: orbbec_astra_depth_raw, width: 640, height: 480, fps: 30}
    }' `
    --teleop.type=so101_leader `
    --teleop.port=COM8 `
    --teleop.id=leader_arm `
    --dataset.repo_id=test/task_v1 `
    --dataset.root=E:\lerobot_images `
    --dataset.single_task="Your task description" `
    --dataset.episode_time_s=3600 `
    --dataset.reset_time_s=10 `
    --dataset.num_episodes=10 `
    --dataset.push_to_hub=false `
    --display_data=true `
    --play_sounds=false
```

LeRobot 会自动检测已有 episodes，从下一个编号续录。例如之前录了 4 个 episode 后崩溃，resume 后直接从 episode 5 开始。相机配置必须和首次录制完全一致。

---

## 七、键盘快捷键汇总

| 按键 | 功能 |
|------|------|
| **Space** | 立即结束当前段，保存后进入 reset |
| **→ 右键** | 同上 |
| **← 左键** | 丢弃当前段，重新录这个 episode |
| **Esc** | 完全停止录制 |

---

## 八、点云训练流程

```powershell
# 1. 导出标定（只需一次）
python -c "from lerobot.cameras.orbbec_astra.camera_orbbec_astra import get_calibration_params; import json; json.dump(get_calibration_params(), open('astra_calib.json','w'), indent=2)"

# 2. 训练（每次训练）
lerobot-train `
    --policy.type=act `
    --dataset.repo_id=test/task_v1 `
    --output_dir=outputs/train/act_xyz `
    --policy.device=cuda `
    --observation_processors.pointcloud.type=pointcloud_processor `
    --observation_processors.pointcloud.depth_key=depth_raw `
    --observation_processors.pointcloud.color_key=color `
    --observation_processors.pointcloud.calib_path=astra_calib.json `
    --observation_processors.pointcloud.max_depth_mm=5000 `
    --observation_processors.pointcloud.xyz_norm_range=[-500,500]
```

标定文件内容结构：
```json
{
  "l_intr_p": [570.34, 570.34, 319.5, 239.5],
  "r_intr_p": [852.48, 852.48, 639.5, 359.5],
  "r2l_r": [0.999..., -0.001..., ...],
  "r2l_t": [24.8, 0.2, -1.3],
  "l_k": [0.0, 0.0, 0.0, 0.0, 0.0],
  "r_k": [0.0, 0.0, 0.0, 0.0, 0.0]
}
```

---

## 九、已知限制与注意事项

| 限制 | 详情 |
|------|------|
| **深度物理上限** | Astra Pro 硬件极限 ~4950mm，无法通过软件突破 |
| **USB 2.0 带宽** | 高分辨率彩色+深度双流可能出现瓶颈，建议彩色 ≤1280×720 |
| **室外深度退化** | 结构光 850nm 方案在室外强光下质量显著下降 |
| **相机索引不稳定** | USB 拔插/重启后索引号可能变化，每次录制前需运行检测脚本 |
| **LeRobot 路径规则** | `LeRobotDataset.create()` 要求目标路径不存在，首次录制需清理旧目录 |
| **彩色/深度无硬同步** | OpenNI2 和 UVC 是独立流，`read_both()` 为软件 best-effort 同步 |
| **Rerun 残留通道** | 上一次会话的通道名会缓存在 viewer 中，关闭 Rerun 窗口后重开即可清除 |
| **`depth_raw` 不可直接查看** | 编码后的 uint8 三通道在 OpenCV/Rerun 中显示为噪声，需 `PointCloudProcessor` 解码 |
| **MSMF 后端兼容性** | Astra Pro 的 UVC 在 Windows MSMF 下可能不稳定，已设置 DShow 为回退 |
| **每次重命名数据集** | 相同 `repo_id` 不能重复录制，换名字或 `--resume=true` 追加 |
| **transient 异常导致空 episode** | 录制循环中相机偶尔超时，缓冲区为空时 `save_episode()` 抛异常 | **已保护**：自动跳过空 episode 并打印警告。用 `--resume=true` 补录 |

---

## 十、相关资料

- [LeRobot 相机系统文档](https://huggingface.co/docs/lerobot/cameras)
- [华南师大 Gemini2 接入 LeRobot 教程](https://wiki.seeedstudio.com/cn/lerobot_so100m/)
- [Orbbec OpenNI_SDK GitHub](https://github.com/orbbec/OpenNI_SDK)
- [pyorbbecsdk GitHub](https://github.com/orbbec/pyorbbecsdk)
- [录制配置指南](computer://E:\ClaudeWorkspace\lerobot_workspace\recording_config_guide.md)
