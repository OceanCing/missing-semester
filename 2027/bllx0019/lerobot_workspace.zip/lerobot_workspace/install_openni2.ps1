# Install OpenNI2 SDK and set environment (Windows x64)
# Run this script as Administrator

$ErrorActionPreference = "Stop"

$SDK_SRC = "E:\ClaudeWorkspace\OpenNI_2.3.0.86_202210111950_4c8f5aa4_beta6_windows"
$INSTALL_DIR = "C:\Program Files\OpenNI2"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  OpenNI2 SDK x64 Installer" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 1. Create target directories
Write-Host "[1/4] Creating install directories..." -ForegroundColor Yellow
$redistDir = "$INSTALL_DIR\Redist"
$driversDir = "$INSTALL_DIR\Redist\OpenNI2\Drivers"
New-Item -ItemType Directory -Force -Path $redistDir | Out-Null
New-Item -ItemType Directory -Force -Path $driversDir | Out-Null
Write-Host "  OK: $redistDir" -ForegroundColor Green

# 2. Copy OpenNI2.dll (x64 Release)
Write-Host "[2/4] Copying OpenNI2.dll (x64)..." -ForegroundColor Yellow
$dllSrc = "$SDK_SRC\Win64-Release\sdk\libs\OpenNI2.dll"
Copy-Item -Force -Path $dllSrc -Destination "$redistDir\OpenNI2.dll"
Write-Host "  OK: OpenNI2.dll copied" -ForegroundColor Green

# 3. Copy Orbbec driver plugin DLL
Write-Host "[3/4] Copying orbbec.dll driver..." -ForegroundColor Yellow
$orbbecSrc = "$SDK_SRC\Win64-Release\sdk\libs\OpenNI2\Drivers\orbbec.dll"
Copy-Item -Force -Path $orbbecSrc -Destination "$driversDir\orbbec.dll"
Write-Host "  OK: orbbec.dll copied" -ForegroundColor Green

# 4. Set environment variable (system-wide)
Write-Host "[4/4] Setting OPENNI2_REDIST64 environment variable..." -ForegroundColor Yellow
[System.Environment]::SetEnvironmentVariable("OPENNI2_REDIST64", $redistDir, "Machine")
# Also set for current process
$env:OPENNI2_REDIST64 = $redistDir
Write-Host "  OK: OPENNI2_REDIST64 = $redistDir" -ForegroundColor Green

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  OpenNI2 SDK installed successfully!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next step: Install the Astra driver." -ForegroundColor Yellow
Write-Host "  Double-click to run:" -ForegroundColor White
Write-Host "  E:\ClaudeWorkspace\astra-win32-driver-4.3.0.22\SensorDriver_V4.3.0.22.exe" -ForegroundColor White
Write-Host ""
Write-Host "After both are installed, run:" -ForegroundColor Yellow
Write-Host "  cd E:\ClaudeWorkspace\lerobot_workspace" -ForegroundColor White
Write-Host "  conda activate lerobot" -ForegroundColor White
Write-Host "  python check_astra.py" -ForegroundColor White
