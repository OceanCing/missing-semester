# LeRobot + Astra Pro 录制配置指南

所有文件改动汇总：

| 文件 | 说明 |
|------|------|
| `src/lerobot/cameras/orbbec_astra/__init__.py` | 新增，注册 `orbbec_astra` / `orbbec_astra_depth` / `orbbec_astra_depth_color` / `orbbec_astra_depth_raw` |
| `src/lerobot/cameras/orbbec_astra/_openni2_ctypes.py` | 新增，OpenNI2 ctypes 封装 + `device_get_camera_params()` + `set_stream_mirror()` |
| `src/lerobot/cameras/orbbec_astra/configuration_orbbec_astra.py` | 新增，四个相机配置类 |
| `src/lerobot/cameras/orbbec_astra/camera_orbbec_astra.py` | 新增，四个相机实现类 + `get_calibration_params()` |
| `src/lerobot/cameras/utils.py` | 修改，加了 `orbbec_astra` / `orbbec_astra_depth` / `orbbec_astra_depth_color` / `orbbec_astra_depth_raw` |
| `src/lerobot/scripts/lerobot_record.py` | 修改，import 了新配置类 + 空 episode 缓冲区保护 |
| `src/lerobot/utils/control_utils.py` | 修改，加了空格键分段功能 |
| `src/lerobot/processor/pointcloud_processor.py` | 新增，点云反投影 + XYZ 融合训练 processor |
| `src/lerobot/processor/__init__.py` | 修改，注册了 `pointcloud_processor` |

---

## 校准从动臂Follower

```Shell
lerobot-calibrate --robot.type=so101_follower --robot.port=COM7 --robot.id=follower_arm
```

## 校准主动臂Leader

```Shell
lerobot-calibrate --teleop.type=so101_leader --teleop.port=COM8 --teleop.id=leader_arm
```

## 文件导出位置（eg）

C:\Users\40743\.cache\huggingface\lerobot\calibration\robots\so101_follower\zihao_follower_arm.json

C:\Users\40743\.cache\huggingface\lerobot\calibration\teleoperators\so101_leader\zihao_leader_arm.json

## 换机械臂

lerobot-calibrate --robot.type=so101_follower --robot.port=COM4 --robot.id=zihao_follower_arm

## 可用相机类型

| type 值 | 类 | 输出 | 用途 |
|---------|-----|------|------|
| `opencv` | `OpenCVCamera` | USB/内置/手机摄像头彩色帧 | 普通视觉 |
| `intelrealsense` | `RealSenseCamera` | Intel RealSense 彩色+深度 | 仅 RealSense 硬件 |
| `orbbec_astra` | `OrbbecAstraCamera` | Astra Pro 彩色帧（UVC） | 主彩色视角 |
| `orbbec_astra_depth` | `OrbbecAstraDepthCamera` | 灰度深度图（默认，"gray" 模式） | 轻量训练，文件小 |
| `orbbec_astra_depth_color` | `OrbbecAstraDepthCamera` | JET 彩色深度映射图（"color" 模式） | 仅可视化 |
| `orbbec_astra_depth_raw` | `OrbbecAstraDepthRawCamera` | 无损编码的 uint16 深度值 | **点云训练** |
| `zmq` | `ZMQCamera` | 网络流相机 | 远程相机 |
| `reachy2_camera` | `Reachy2Camera` | Reachy2 机器人相机 | Reachy2 |

---

## camera 配置参数

### opencv（普通摄像头）

```yaml
{type: opencv, index_or_path: 0, width: 640, height: 480, fps: 30}
```

| 参数 | 必需 | 说明 |
|------|------|------|
| `index_or_path` | 是 | 摄像头索引号（0, 1, 2...） |
| `width` | 否 | 分辨率宽，不设则用硬件默认 |
| `height` | 否 | 分辨率高 |
| `fps` | 否 | 帧率 |
| `color_mode` | 否 | `rgb`（默认）或 `bgr` |
| `rotation` | 否 | `0` / `90` / `180` / `270` |

### orbbec_astra（Astra Pro 彩色）

```yaml
{type: orbbec_astra, color_index: 0, use_depth: true, width: 1280, height: 720, fps: 30}
```

| 参数 | 必需 | 说明 |
|------|------|------|
| `color_index` | 是 | UVC 彩色流的设备索引号 |
| `use_depth` | 否 | 是否初始化共享深度流（默认 true，**必须为 true 才能用深度相机**） |
| `width` | 否 | 分辨率宽（Windows MSMF 可能强制设不了，会自动接受实际值） |
| `height` | 否 | 分辨率高 |
| `fps` | 否 | 帧率 |
| `color_mode` | 否 | `rgb`（默认）或 `bgr` |
| `focus_range` | 否 | 深度有效范围 (min_mm, max_mm)，默认 (200, 5000) |

### orbbec_astra_depth（Astra Pro 灰度深度图，省空间）

```yaml
{type: orbbec_astra_depth, width: 640, height: 480, fps: 30}
```

| 参数 | 必需 | 说明 |
|------|------|------|
| `mode` | 否 | `"gray"` 输出单通道灰度×3（默认，文件极小），`"color"` 输出 JET 彩色映射图 |
| `width` | 否 | 输出深度图的宽，默认 640 |
| `height` | 否 | 输出深度图的高，默认 480 |
| `fps` | 否 | 帧率，默认 30 |
| `min_depth_mm` | 否 | 灰度/颜色映射最小深度(mm)，默认 250 |
| `max_depth_mm` | 否 | 灰度/颜色映射最大深度(mm)，默认 1300 |

> 默认输出单通道灰度堆叠三通道。视频编码器对三个完全相同的通道压缩效率极高，体积约 JET 彩色图的 1/3。ACT 训练效果完全一样（灰度/彩色对卷积特征提取无区别）。如需 Rerun 直观查看，另加一个 `orbbec_astra_depth_color` 通道。

### orbbec_astra_depth_color（Astra Pro JET 彩色深度图，仅查看）

```yaml
{type: orbbec_astra_depth_color, width: 640, height: 480, fps: 30}
```

> 与 `orbbec_astra_depth` 完全相同，但固定输出 JET 彩色映射图。仅推荐用于 Rerun 可视化查看深度分布，不建议用于训练（文件约 3 倍大）。

### orbbec_astra_depth_raw（Astra Pro 原始深度，无损）

```yaml
{type: orbbec_astra_depth_raw, width: 640, height: 480, fps: 30}
```

| 参数 | 必需 | 说明 |
|------|------|------|
| `width` | 否 | 输出深度图的宽，默认 640 |
| `height` | 否 | 输出深度图的高，默认 480 |
| `fps` | 否 | 帧率，默认 30 |
| `min_depth_mm` | 否 | 截断最小深度(mm)，默认 250 |
| `max_depth_mm` | 否 | 截断最大深度(mm)，默认 1300 |

> 编码方式：Channel 0 = 深度低字节，Channel 1 = 深度高字节，Channel 2 = 0。
> 3 通道 uint8 兼容 LeRobot 图像 pipeline，可通过 `PointCloudProcessorStep` 无损还原为 uint16 深度值并反投影为 XYZ 点云。

**重要**：所有 `orbbec_astra_depth*` 类型必须**排在** `orbbec_astra`（设了 `use_depth: true`）**后面**。排序决定了相机初始化顺序——Astra 彩色相机先连接并启动共享的 OpenNI2 深度流，深度相机随后复用这个连接。

---

## 录制命令模板

```powershell
lerobot-record `
    --robot.type=so101_follower `
    --robot.port=COM7 `
    --robot.id=follower_arm `
    --robot.cameras='{
        相机名1: {type: 类型, ...},
        相机名2: {type: 类型, ...}
    }' `
    --teleop.type=so101_leader `
    --teleop.port=COM8 `
    --teleop.id=leader_arm `
    --dataset.repo_id=你的名字/数据集名 `
    --dataset.single_task="任务描述" `
    --dataset.episode_time_s=3600 `
    --dataset.reset_time_s=10 `
    --dataset.num_episodes=10 `
    --dataset.push_to_hub=false `
    --display_data=true `
    --play_sounds=false
```

## 测试启动命令模板

## (正式采集记得删除Remove-Item)

```powershell
python -c "import cv2; [print(f'Index {i}: {cv2.VideoCapture(i).read()[1].shape}') for i in range(10) if cv2.VideoCapture(i).isOpened()]"

Remove-Item -Force -Recurse E:\lerobot_dateset\images

lerobot-record `
    --robot.type=so101_follower `
    --robot.port=COM7 `
    --robot.id=follower_arm `
    --robot.cameras='{
        color: {type: orbbec_astra, color_index: 2, use_depth: true, mirror: false, width: 640, height: 480, fps: 30},
        depth_viz: {type: orbbec_astra_depth, width: 640, height: 480, fps: 30, min_depth_mm: 250, max_depth_mm: 1250},
        depth_viz_color: {type: orbbec_astra_depth_color, width: 640, height: 480, fps: 30, min_depth_mm: 250, max_depth_mm: 1250},
        depth_raw: {type: orbbec_astra_depth_raw, width: 640, height: 480, fps: 30, min_depth_mm: 250, max_depth_mm: 1250},
        camera1: {type: opencv, index_or_path: 0, width: 640, height: 480, fps: 30},
        camera2: {type: opencv, index_or_path: 3, width: 640, height: 480, fps: 30},
        camera3: {type: opencv, index_or_path: 1, width: 640, height: 480, fps: 30},
        camera6: {type: opencv, index_or_path: 5, width: 640, height: 480, fps: 30}
    }' `
    --teleop.type=so101_leader `
    --teleop.port=COM8 `
    --teleop.id=leader_arm `
    --dataset.repo_id=test/full_v1 `
    --dataset.root=E:\lerobot_dateset\images `
    --dataset.single_task="unit_level_1" `
    --dataset.episode_time_s=3600 `
    --dataset.reset_time_s=10 `
    --dataset.num_episodes=10 `
    --dataset.push_to_hub=false `
    --display_data=true `
    --play_sounds=false
```

### 从中断点接续录制

录制中途崩溃或手动停止后，加 `--resume=true` 即可续录，其他参数保持不变：

```powershell
$env:HF_HUB_OFFLINE = "1"
lerobot-record `
    --resume=true `
    --robot.type=so101_follower `
    --robot.port=COM7 `
   --robot.id=follower_arm `
    --robot.cameras='{
        color: {type: orbbec_astra, color_index: 2, use_depth: true, mirror: false, width: 640, height: 480, fps: 30},
        depth_viz: {type: orbbec_astra_depth, width: 640, height: 480, fps: 30, min_depth_mm: 250, max_depth_mm: 1250},
        depth_viz_color: {type: orbbec_astra_depth_color, width: 640, height: 480, fps: 30, min_depth_mm: 250, max_depth_mm: 1250},
        depth_raw: {type: orbbec_astra_depth_raw, width: 640, height: 480, fps: 30, min_depth_mm: 250, max_depth_mm: 1250},
        camera1: {type: opencv, index_or_path: 0, width: 640, height: 480, fps: 30},
        camera2: {type: opencv, index_or_path: 3, width: 640, height: 480, fps: 30},
        camera3: {type: opencv, index_or_path: 1, width: 640, height: 480, fps: 30},
        camera6: {type: opencv, index_or_path: 5, width: 640, height: 480, fps: 30}
    }' `
    --teleop.type=so101_leader `
    --teleop.port=COM8 `
    --teleop.id=leader_arm `
    --dataset.repo_id=test/full_v1 `
    --dataset.root=E:\lerobot_dateset\images `
    --dataset.single_task="unit_level_1" `
    --dataset.episode_time_s=3600 `
    --dataset.reset_time_s=10 `
    --dataset.num_episodes=10 `
    --dataset.push_to_hub=false `
    --display_data=true `
    --play_sounds=false
```

LeRobot 自动检测已有 episodes，从下一个编号续录。相机配置必须和首次录制完全一致。



```Shell
lerobot-teleoperate --robot.type=so101_follower --robot.port=COM7 --robot.id=follower_arm --teleop.type=so101_leader --teleop.port=COM8 --teleop.id=leader_arm
```

### 数据集参数

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `repo_id` | 必需 | `用户名/数据集名`，本地存储用 test 做用户名 |
| `single_task` | 必需 | 任务描述，如 "Grab red cube" |
| `episode_time_s` | 60 | 每段最大时长（秒），设大后用空格键手动分段 |
| `reset_time_s` | 60 | 每段之间的复位时间（秒） |
| `num_episodes` | 50 | 最多录几段 |
| `fps` | 30 | 录制帧率 |
| `push_to_hub` | true | 是否上传到 HuggingFace Hub |
| `video` | true | 是否编码视频 |
| `resume` | false | 是否追加到已有数据集 |

### 机械臂 / 遥操作参数

| 参数 | 说明 |
|------|------|
| `--robot.type=` | `so101_follower` / `so100_follower` 等 |
| `--robot.port=` | Follower 从臂 COM 口 |
| `--robot.id=` | 标定文件用的 ID（任意名字） |
| `--teleop.type=` | `so101_leader` / `so100_leader` 等 |
| `--teleop.port=` | Leader 主臂 COM 口 |

---

## 录制前：检查摄像头索引

摄像头索引号（`index_or_path` / `color_index`）在拔插 USB 或重启电脑后可能变化。每次录制前建议先确认：

```powershell
python -c "import cv2; [print(f'Index {i}: {cv2.VideoCapture(i).read()[1].shape}') for i in range(10) if cv2.VideoCapture(i).isOpened()]"
```

输出示例：
```
Index 0: (480, 640, 3)     ← 笔记本内置摄像头
Index 1: (480, 640, 3)     ← 外接 USB 摄像头
Index 2: (720, 1280, 3)    ← Astra Pro 彩色（看分辨率确认）
Index 3: (480, 640, 3)     ← 外接 USB 摄像头
```

Astra Pro 彩色流通常是 1280×720 或 640×480，分辨率最高的那个往往就是它。确认后在 `--robot.cameras` 里填对应的索引号。

如果索引和实体相机对不上号，用这个脚本一帧一帧看：

```powershell
python -c "
import cv2
for i in range(6):
    cap = cv2.VideoCapture(i)
    if not cap.isOpened():
        cap.release()
        continue
    ret, frame = cap.read()
    if ret:
        h, w = frame.shape[:2]
        cv2.putText(frame, f'Index {i}', (30, 60),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 255, 0), 3)
        cv2.putText(frame, f'{w}x{h}', (30, 100),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        cv2.imshow(f'Camera Index {i}', frame)
    cap.release()
print('Press any key to close...')
cv2.waitKey(0)
cv2.destroyAllWindows()
"
```

每个摄像头的画面会弹出来，左上角标了索引号，对着镜头挥手就能辨认。

---

## 常用配置方案

### 方案 1：Astra Pro 彩色 + JET 深度映射图（基础方案）

**录制：**

```powershell
Remove-Item -Force -Recurse C:\Users\bllx\.cache\huggingface\lerobot\test\*

--robot.cameras='{
    color: {type: orbbec_astra, color_index: 0, use_depth: true, width: 1280, height: 720, fps: 30},
    depth: {type: orbbec_astra_depth, width: 640, height: 480, fps: 30}
}'
```

数据集特征：`color` (1280×720 RGB) + `depth` (640×480 JET colormap)

训练：标准 ACT 训练，深度图作为独立的 3 通道图像特征输入。

### 方案 2：Astra Pro 彩色 + 原始深度 + 点云训练（Plan B）

这是能利用精确深度值参与训练的完整方案。

**2a. 录制：**

```powershell
Remove-Item -Force -Recurse C:\Users\bllx\.cache\huggingface\lerobot\test\*

lerobot-record `
    --robot.type=so101_follower `
    --robot.port=COM7 `
    --robot.id=follower_arm `
    --robot.cameras='{
        color: {type: orbbec_astra, color_index: 0, use_depth: true, width: 1280, height: 720, fps: 30},
        depth: {type: orbbec_astra_depth_raw, width: 640, height: 480, fps: 30}
    }' `
    --teleop.type=so101_leader `
    --teleop.port=COM8 `
    --teleop.id=leader_arm `
    --dataset.repo_id=test/pick_cube_v1 `
    --dataset.single_task="Pick the red cube" `
    --dataset.episode_time_s=3600 `
    --dataset.reset_time_s=10 `
    --dataset.num_episodes=10 `
    --dataset.push_to_hub=false `
    --display_data=true `
    --play_sounds=false
```

数据集特征：`color` (1280×720 RGB) + `depth` (640×480 无损编码 uint16)

**2b. 保存相机标定参数（录完后跑一次）：**

```powershell
python -c "
from lerobot.cameras.orbbec_astra.camera_orbbec_astra import get_calibration_params
import json
calib = get_calibration_params()
with open('astra_calib.json', 'w') as f: json.dump(calib, f, indent=2)
print('Saved to astra_calib.json')
print('l_intr_p:', calib['l_intr_p'])
print('r_intr_p:', calib['r_intr_p'])
print('r2l_r:', calib['r2l_r'])
print('r2l_t:', calib['r2l_t'])
"
```

输出示例：
```
l_intr_p: [570.342224, 570.342224, 319.5, 239.5]   ← 深度相机内参
r_intr_p: [852.478088, 852.478088, 639.5, 359.5]   ← 彩色相机内参
r2l_r: [0.999..., -0.001..., ...]                    ← 彩色→深度旋转
r2l_t: [24.8, 0.2, -1.3]                            ← 彩色→深度平移(mm)
```

**2c. 训练：**

```powershell
lerobot-train `
    --policy.type=act `
    --dataset.repo_id=test/pick_cube_v1 `
    --output_dir=outputs/train/act_pointcloud `
    --policy.device=cuda `
    --observation_processors.pointcloud.type=pointcloud_processor `
    --observation_processors.pointcloud.depth_key=depth `
    --observation_processors.pointcloud.color_key=color `
    --observation_processors.pointcloud.calib_path=astra_calib.json `
    --observation_processors.pointcloud.max_depth_mm=5000 `
    --observation_processors.pointcloud.xyz_norm_range=[-500,500] `
    --wandb.enable=true
```

训练 pipeline 自动完成：
1. 解码 depth 帧 → 重建 uint16 深度值 (mm)
2. 用深度内参 `l_intr_p` 反投影 → (640, 480, 3) XYZ 坐标图
3. 归一化 XYZ 到 [-1, 1] 范围
4. 双线性插值缩放至 RGB 分辨率 (1280, 720)
5. 将 `depth` 特征替换为 XYZ 张量送入 ACT 模型

`pointcloud_processor` 参数：

| 参数 | 必需 | 说明 |
|------|------|------|
| `depth_key` | 是 | 数据集中原始深度特征的键名 |
| `color_key` | 否 | 数据集中彩色特征的键名（用于对齐分辨率） |
| `calib_path` | 否 | 标定 JSON 文件路径，留空则用 Astra Pro 出厂默认值 |
| `max_depth_mm` | 否 | 深度上限(mm)，超过此值的像素视为无效，默认 5000 |
| `xyz_norm_range` | 否 | XYZ 归一化范围 [min, max]，默认 [-500, 500] mm |

### 方案 3：Astra Pro + 笔记本摄像头

```powershell
--robot.cameras='{
    color: {type: orbbec_astra, color_index: 0, use_depth: true, width: 1280, height: 720, fps: 30},
    depth: {type: orbbec_astra_depth_raw, width: 640, height: 480, fps: 30},
    front: {type: opencv, index_or_path: 1, width: 640, height: 480, fps: 30}
}'
```

### 方案 4：只用普通摄像头（无深度）

```powershell
--robot.cameras='{
    front: {type: opencv, index_or_path: 0, width: 640, height: 480, fps: 30}
}'
```

### 方案 5：只用 Astra Pro 彩色（不用深度）

```powershell
--robot.cameras='{
    color: {type: orbbec_astra, color_index: 0, use_depth: false, width: 1280, height: 720, fps: 30}
}'
```

---

## 键盘快捷键

| 按键 | 功能 |
|------|------|
| **Space 空格** | 立即结束当前段，保存后进入 reset |
| **→ 右键** | 同上 |
| **← 左键** | 丢弃当前段，重新录这个 episode |
| **Esc** | 完全停止录制 |

深度范围通过 `--robot.cameras` 中的 `min_depth_mm` / `max_depth_mm` 参数预设（默认 250 / 1300 mm）：

```
depth_viz: {type: orbbec_astra_depth, min_depth_mm: 300, max_depth_mm: 2000}
```

---

## 点云训练完整流程速查

从头到尾走 Plan B 只需要四步：

```powershell
# 1. 录制（每条数据集一个命令）
Remove-Item -Force -Recurse ~/.cache/huggingface/lerobot/test/*
lerobot-record --robot.type=so101_follower --robot.port=COM7 --robot.id=follower_arm `
    --robot.cameras='{color:{type:orbbec_astra,color_index:0,use_depth:true,width:1280,height:720,fps:30},depth:{type:orbbec_astra_depth_raw,width:640,height:480,fps:30}}' `
    --teleop.type=so101_leader --teleop.port=COM8 --teleop.id=leader_arm `
    --dataset.repo_id=test/my_task_v1 --dataset.single_task="My task" `
    --dataset.num_episodes=10 --dataset.push_to_hub=false --display_data=true --play_sounds=false

# 2. 导出标定（只需一次）
python -c "from lerobot.cameras.orbbec_astra.camera_orbbec_astra import get_calibration_params; import json; json.dump(get_calibration_params(), open('astra_calib.json','w'), indent=2)"

# 3. 训练
lerobot-train --policy.type=act --dataset.repo_id=test/my_task_v1 --output_dir=outputs/train/act_xyz `
    --policy.device=cuda --observation_processors.pointcloud.type=pointcloud_processor `
    --observation_processors.pointcloud.depth_key=depth `
    --observation_processors.pointcloud.color_key=color `
    --observation_processors.pointcloud.calib_path=astra_calib.json

# 4. 评估
lerobot-eval --policy.path=outputs/train/act_xyz/checkpoints/last/pretrained_model `
    --dataset.repo_id=test/my_task_v1 --policy.device=cuda
```

---

## 故障排查

| 症状 | 原因 | 解决 |
|------|------|------|
| `FileExistsError` | 数据集已存在 | LeRobot 要求目标路径不存在，会自己创建。删除整个目录：`Remove-Item -Force -Recurse E:\lerobot_images`（默认路径用 `~/.cache/huggingface/lerobot/test/`），或者换一个 `repo_id`。注意清理的是 `--dataset.root` 下的完整路径，不是 repo_id 本身 |
| `ConnectionError` 相机打不开 | MSMF 后端冲突 | 已自动回退 DShow，若仍然失败拔插 USB 后重试 |
| Leader 没反应 | 主臂没通电或端口错 | 检查电源适配器，设备管理器确认 COM 口 |
| Rerun 没画面 | 正常，会在桌面弹窗 | 找名为 "rerun" 的窗口 |
| 深度流没启动 | color 相机没有 `use_depth: true` | 确保 orbbec_astra 配了 `use_depth: true` |
| 校准提示 | 首次运行或换了臂 | 按提示手动摆臂活动关节，后续按 Enter 跳过 |
| 深度帧解码后全为 0 | 相机离物体太远或 focus_range 不匹配 | 检查 `min_depth_mm` / `max_depth_mm` 参数 |
| 点云训练时报 calib 文件找不到 | 标定文件路径不对 | 用绝对路径或放在项目根目录 |
| XYZ 归一化范围溢出 | `xyz_norm_range` 太窄 | 扩大范围如 `[-1000, 1000]` |
| `save_episode()` 报空 buffer | 录制循环因 transient 异常提前退出 | 已保护——自动跳过并打印警告。用 `--resume=true` 补录跳过的 episode |



```
lerobot-train \
  --dataset.repo_id=bllx/unit_Lv.1_baseline_50 \
  --dataset.root=~/lerobot_dateset \
  --dataset.revision=v0.1.0 \
  --dataset.streaming=false \
  --policy.type=act \
  --output_dir=~/output_lerobot_train/act/ \
  --job_name=unit_lv1 \
  --policy.device=cuda \
  --wandb.enable=true \
  --wandb.project=unit_Lv.1_baseline_50 \
  --policy.push_to_hub=false \
  --steps=20000 \
  --batch_size=16
```

