# LeRobot 训练服务器环境配置指南

## 环境

- OS：Ubuntu 22.04（Featurize 云实例）
- GPU：24 GB VRAM
- CUDA：13.0（跟随 PyTorch）

---

## 1. 创建 Python 环境

```bash
conda create -y -n lerobot python=3.12
conda activate lerobot
```

---

## 2. 安装系统依赖

```bash
conda install ffmpeg=7.1.1 -c conda-forge -y
```

> 必须用 conda-forge 的版本。conda 默认 channel 的 FFmpeg 版本太旧，会导致 `torchcodec` 找共享库失败。

---

## 3. Clone LeRobot 源码

```bash
git clone https://github.com/huggingface/lerobot.git ~/lerobot
cd ~/lerobot
```

---

## 4. 安装 LeRobot + 所有依赖

```bash
pip install -e ".[pi,datasets,training]"
```

> `[pi]` — π0 模型必需包（torch, torchvision, opencv-python-headless 等）
> `[datasets]` — 数据集读写（datasets, av 视频解码）
> `[training]` — 训练必需（accelerate, ipython 等）

### 4.1 注意：av 版本兼容性

如果后续报 `module 'av' has no attribute 'option'`，降级到兼容版本：

```bash
pip install "av<14"
```

---

## 5. 安装 WandB（可选）

```bash
pip install wandb --upgrade
wandb login    # 交互式登陆
```

---

## 6. HuggingFace 登陆

```bash
hf auth login
```

### 常见问题

#### 代理报错 `ImportError: Using SOCKS proxy, but the 'socksio' package is not installed`

```bash
pip install "httpx[socks]"
```

#### 浏览器登录失败

选 `Paste an access token`，从 https://huggingface.co/settings/tokens 创建 token 粘贴。

---

## 7. 上传数据集到服务器

### 方式 A：从 Windows / MacOS → 上传到 HuggingFace Hub → 服务器流式读取

```powershell
# 在原始录制机器上
huggingface-cli upload 你的用户名/数据集名 E:\lerobot_dateset\images\test\full_v1 --repo-type dataset
```

服务器上训练时：

```bash
lerobot-train \
  --dataset.repo_id=你的用户名/数据集名 \
  --dataset.streaming=true \
  ...
```

### 方式 B：直接上传到服务器本地（Featurize）

在 Featurize 控制台上传 zip，然后：

```bash
featurize dataset extract <dataset-uuid>
```

解压后确认路径结构：

```bash
find ~ -name "info.json" 2>/dev/null
# 应输出类似: /home/featurize/xxx/meta/info.json
```

---

## 8. 调整数据集路径

LeRobot 的数据集结构必须是：

```
{dataset.root}/{dataset.repo_id}/meta/info.json
{dataset.root}/{dataset.repo_id}/data/
{dataset.root}/{dataset.repo_id}/videos/
```

### 如果 meta 文件在错误位置

假设解压后 meta 在 `~/lerobot_dateset/images/meta/info.json`：

```bash
# 移入正确的子目录
mkdir -p /home/featurize/lerobot_dateset/test/full_v1
cd /home/featurize/lerobot_dateset/images
mv meta data videos /home/featurize/lerobot_dateset/test/full_v1/
```

---

## 9. 启动训练

### 基础命令

```bash
rm -rf /home/featurize/output/unit_act && \
HF_HUB_OFFLINE=1 lerobot-train \
  --dataset.repo_id=test/full_v1 \
  --dataset.root=/home/featurize/lerobot_dateset/test/full_v1 \
  --dataset.streaming=false \
  --dataset.video_backend=pyav \
  --policy.type=act \
  --output_dir=/home/featurize/output/unit_act \
  --job_name=unit_le1 \
  --policy.device=cuda \
  --wandb.enable=true \
  --wandb.project=unit_Lv.1_baseline_50 \
  --policy.push_to_hub=false \
  --steps=20000 \
  --batch_size=4
```

### 参数说明

| 参数 | 说明 |
|------|------|
| `HF_HUB_OFFLINE=1` | 跳过 Hub 版本检查，本地数据集必需 |
| `--dataset.root` | 指向包含 `meta/` 的那级目录 |
| `--dataset.video_backend=pyav` | 用 PyAV 解码视频，不用 TorchCodec（FFmpeg 共享库兼容性问题） |
| `--batch_size=4` | 1280×720 多通道数据建议 ≤4，否则 CUDA OOM |
| `--steps=20000` | 训练步数 |
| `rm -rf ...` | 每次失败后清理上次的空输出目录 |

### 如果 CUDA 内存不够

报错 `torch.OutOfMemoryError` 时：

1. **降低 batch_size**：`--batch_size=2` 或 `--batch_size=1`
2. **降低学习率配套**：batch_size 减半时建议同步减半 lr，如 `--optimizer.lr=5e-6`
3. **根本解决**：录制时用 640×480 分辨率而非 1280×720（训练效果几乎无差异，显存省大半）

---

## 10. 训练后续

### 查看进度

WandB 仪表盘：https://wandb.ai （训练启动时终端会打印链接）

### 恢复中断的训练

```bash
HF_HUB_OFFLINE=1 lerobot-train \
  --resume=true \
  --dataset.repo_id=test/full_v1 \
  --dataset.root=/home/featurize/lerobot_dateset/test/full_v1 \
  --dataset.video_backend=pyav \
  --policy.type=act \
  --output_dir=/home/featurize/output/unit_act \
  --policy.device=cuda \
  ...
```

### 模型权重位置

```
/home/featurize/output/unit_act/checkpoints/last/pretrained_model/
```

---

## 11. 故障速查

| 症状 | 原因 | 解决 |
|------|------|------|
| `ImportError: 'datasets' required` | 缺少 `datasets` extra | `pip install -e ".[pi,datasets,training]"` |
| `module 'av' has no attribute 'option'` | av 版本太新 | `pip install "av<14"` |
| `FileNotFoundError: meta/info.json` | root 路径不对 | root 需指向包含 `meta/` 的目录 |
| `RepositoryNotFoundError` / `BackwardCompatibilityError` | 本地数据集但 LeRobot 尝试查 Hub | 加 `HF_HUB_OFFLINE=1` |
| `CUDA out of memory` | 图像分辨率太高 / batch_size 太大 | 降低 batch_size 或重录 640×480 |
| `torchcodec` FFmpeg 共享库加载失败 | 系统 FFmpeg 版本不匹配 | 加 `--dataset.video_backend=pyav` |
| `FileExistsError: Output directory` | 上次失败留下的空目录 | `rm -rf <output_dir>` |
| `ImportError: Using SOCKS proxy` | httpx 代理检测到 socks 配置但缺 socksio | `pip install "httpx[socks]"` |

---

## 附：快速环境重建（一条命令）

一台全新服务器上，从头跑完所有安装：

```bash
conda create -y -n lerobot python=3.12
conda activate lerobot
conda install ffmpeg=7.1.1 -c conda-forge -y
git clone https://github.com/huggingface/lerobot.git ~/lerobot
cd ~/lerobot
pip install -e ".[pi,datasets,training]"
pip install "av<14"
pip install wandb --upgrade
pip install "httpx[socks]"
```

然后加数据集、登陆 HuggingFace、WandB，跑训练。总共约 15 分钟。
