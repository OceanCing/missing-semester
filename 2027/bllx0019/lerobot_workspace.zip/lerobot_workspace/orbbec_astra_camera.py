"""
Orbbec Astra Pro camera adapter for LeRobot.

The Astra Pro uses the OpenNI2 protocol for depth and standard UVC for
colour.  This adapter bridges both streams into a single class that
follows LeRobot's camera interface.

Depth driver: _openni2_ctypes (ctypes wrapper around OpenNI2 C API).
Colour driver: OpenCV VideoCapture (UVC).

No `pip install openni` needed — the ctypes module directly loads the
system-installed OpenNI2 shared library.

Requirements:
    pip install numpy opencv-python
    + Orbbec OpenNI2 SDK (https://developer.orbbec.com.cn)
"""

import logging
import threading
import time
from typing import Optional, Tuple

import numpy as np

from lerobot.cameras.configs import ColorMode, Cv2Rotation
from configuration_astra import OrbbecAstraCameraConfig

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Colour helpers
# ---------------------------------------------------------------------------

def _bgr_to_rgb(frame: np.ndarray) -> np.ndarray:
    try:
        import cv2
        return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    except ImportError:
        return frame


def _rotate_frame(frame: np.ndarray, rotation: Cv2Rotation) -> np.ndarray:
    if rotation == Cv2Rotation.NO_ROTATION:
        return frame
    try:
        import cv2
        mapping = {
            Cv2Rotation.ROTATE_90_CLOCKWISE: cv2.ROTATE_90_CLOCKWISE,
            Cv2Rotation.ROTATE_90_COUNTERCLOCKWISE: cv2.ROTATE_90_COUNTERCLOCKWISE,
            Cv2Rotation.ROTATE_180: cv2.ROTATE_180,
        }
        code = mapping.get(rotation)
        if code is not None:
            return cv2.rotate(frame, code)
    except ImportError:
        pass
    return frame


# ===================================================================
# Camera
# ===================================================================

class OrbbecAstraCamera:
    """LeRobot-compatible camera adapter for Orbbec Astra Pro.

    Factory dispatch: mock → _MockAstraCamera, else real camera.
    """

    def __new__(cls, config: OrbbecAstraCameraConfig):
        if config.mock:
            obj = object.__new__(_MockAstraCamera)
            obj.__init__(config)
            return obj
        obj = object.__new__(_RealAstraCamera)
        obj.__init__(config)
        return obj


# ===================================================================
# Real camera
# ===================================================================

class _RealAstraCamera:
    def __init__(self, config: OrbbecAstraCameraConfig):
        self.config = config
        self._oni = None          # OpenNI2 instance
        self._dev = None          # OpenNI device handle
        self._depth_stream = None # OpenNI depth stream handle
        self._cap = None          # cv2.VideoCapture for colour
        self._color_lock = threading.Lock()
        self._depth_lock = threading.Lock()
        self._connected = False

    # ---- connection --------------------------------------------------

    def connect(self) -> None:
        if self._connected:
            logger.warning("Already connected — skipping")
            return

        self._init_openni()
        self._init_color()
        self._warmup()
        self._connected = True
        logger.info("OrbbecAstraCamera connected")

    def disconnect(self) -> None:
        if self._depth_stream is not None and self._oni is not None:
            self._oni.stream_stop(self._depth_stream)
            self._depth_stream = None
        if self._dev is not None and self._oni is not None:
            self._oni.device_close(self._dev)
            self._dev = None
        if self._oni is not None:
            self._oni.shutdown()
            self._oni = None
        if self._cap is not None:
            self._cap.release()
            self._cap = None
        self._connected = False
        logger.info("OrbbecAstraCamera disconnected")

    def _init_openni(self) -> None:
        from _openni2_ctypes import OpenNI2

        self._oni = OpenNI2(self.config.openni2_lib_path)
        self._oni.initialize()
        self._dev = self._oni.device_open_any()

        info = self._oni.device_get_info(self._dev)
        logger.info(f"OpenNI2 device: {info}")

        self._depth_stream = self._oni.create_depth_stream(self._dev)
        self._oni.stream_start(self._depth_stream)
        logger.info("Depth stream started")

    def _init_color(self) -> None:
        try:
            import cv2
        except ImportError:
            raise ImportError("opencv-python required. Run: pip install opencv-python")

        self._cv2 = cv2
        idx = self.config.color_index
        self._cap = cv2.VideoCapture(idx)

        if not self._cap.isOpened():
            alt = 0 if idx == 1 else 1
            logger.warning(f"Colour stream not at index {idx}, trying {alt}...")
            self._cap = cv2.VideoCapture(alt)
            if not self._cap.isOpened():
                msg = f"Could not open colour stream at index {idx} or {alt}"
                raise RuntimeError(msg)

        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.config.width)
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.config.height)
        self._cap.set(cv2.CAP_PROP_FPS, self.config.fps)

    def _warmup(self) -> None:
        logger.info(f"Warming up ({self.config.warmup_frames} frames)...")
        for _ in range(self.config.warmup_frames):
            if self._oni is not None:
                self._oni.read_depth_frame(self._depth_stream)
            self._read_color_raw()
            time.sleep(0.05)

    # ---- read (synchronous) ------------------------------------------

    def read(self) -> np.ndarray:
        """Blocking colour frame read."""
        self._require_connected()
        color = None
        while color is None:
            color = self._read_color_raw()
        return self._post_color(color)

    def read_depth(self) -> np.ndarray:
        """Blocking depth frame read.  Returns float32 mm array."""
        self._require_connected()
        depth = None
        while depth is None:
            depth = self._oni.read_depth_frame(self._depth_stream)
        return self._clamp_depth(depth)

    def read_both(self) -> Tuple[np.ndarray, np.ndarray]:
        """Read colour + depth (best-effort sync)."""
        return self.read(), self.read_depth()

    # ---- read (asynchronous) -----------------------------------------

    def async_read(self, timeout_ms: int = 200) -> Optional[np.ndarray]:
        self._require_connected()
        deadline = time.perf_counter() + timeout_ms / 1000.0
        while time.perf_counter() < deadline:
            c = self._read_color_raw()
            if c is not None:
                return self._post_color(c)
            time.sleep(0.001)
        return None

    def async_read_depth(self, timeout_ms: int = 200) -> Optional[np.ndarray]:
        self._require_connected()
        deadline = time.perf_counter() + timeout_ms / 1000.0
        while time.perf_counter() < deadline:
            d = self._oni.read_depth_frame(self._depth_stream)
            if d is not None:
                return self._clamp_depth(d)
            time.sleep(0.001)
        return None

    def async_read_both(
        self, timeout_ms: int = 200
    ) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
        return self.async_read(timeout_ms), self.async_read_depth(timeout_ms)

    # ---- internal helpers --------------------------------------------

    def _read_color_raw(self) -> Optional[np.ndarray]:
        with self._color_lock:
            ret, frame = self._cap.read()
            return frame if ret else None

    def _post_color(self, frame: np.ndarray) -> np.ndarray:
        if self.config.color_mode == ColorMode.RGB and frame.shape[-1] == 3:
            frame = _bgr_to_rgb(frame)
        return _rotate_frame(frame, self.config.rotation)

    def _clamp_depth(self, depth: np.ndarray) -> np.ndarray:
        lo, hi = self.config.focus_range
        return np.where((depth >= lo) & (depth <= hi), depth, 0.0)

    def _require_connected(self) -> None:
        if not self._connected:
            raise RuntimeError("Camera not connected. Call connect() first.")

    # ---- context manager ---------------------------------------------

    @property
    def is_connected(self) -> bool:
        return self._connected

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *args):
        self.disconnect()


# ===================================================================
# Mock (testing without hardware)
# ===================================================================

class _MockAstraCamera:
    def __init__(self, config: OrbbecAstraCameraConfig):
        self.config = config
        self._connected = False

    def connect(self):
        self._connected = True
        logger.info("Mock camera connected")

    def disconnect(self):
        self._connected = False

    def read(self) -> np.ndarray:
        return np.random.randint(
            0, 255, (self.config.height, self.config.width, 3), dtype=np.uint8
        )

    def read_depth(self) -> np.ndarray:
        lo, hi = self.config.focus_range
        return np.random.uniform(
            lo, hi, (self.config.depth_height, self.config.depth_width)
        ).astype(np.float32)

    def read_both(self) -> Tuple[np.ndarray, np.ndarray]:
        return self.read(), self.read_depth()

    def async_read(self, timeout_ms=200):
        return self.read()

    def async_read_depth(self, timeout_ms=200):
        return self.read_depth()

    def async_read_both(self, timeout_ms=200):
        return self.read_both()

    @property
    def is_connected(self):
        return self._connected

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *args):
        self.disconnect()


# ===================================================================
# Quick test
# ===================================================================
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    config = OrbbecAstraCameraConfig(warmup_frames=5, mock=True)
    with OrbbecAstraCamera(config) as cam:
        c, d = cam.read_both()
        print(f"Colour: {c.shape}, Depth: {d.shape}")
        valid = d[d > 0]
        if len(valid) > 0:
            print(f"Depth range: [{valid.min():.0f}, {valid.max():.0f}] mm")
